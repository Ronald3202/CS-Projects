#include <linux/kernel.h>
#include <linux/init.h>
#include <linux/module.h>
#include <linux/moduleparam.h>
#include <linux/kthread.h>
#include <linux/sched.h>
#include <linux/semaphore.h>
#include <linux/delay.h>

// Module metadata
#define AUTHOR "Your Name Here"
MODULE_LICENSE("GPL");
MODULE_AUTHOR(AUTHOR);
MODULE_DESCRIPTION("A simple producer-consumer kernel module");

// Semaphores for synchronization
struct semaphore sem_empty;
struct semaphore sem_full;
struct semaphore sem_mutex;

// Task structures for the kernel threads
struct task_struct *kernel_threads[2];

// Parameter structure for thread information
struct thread_params { 
    char name[100]; 
    int sequence; 
    int buffer_index; 
    int thread_id; 
};
struct thread_params thread_data[2];

// Pointers for buffer manipulation
int buffer_write_ptr = 0;
int buffer_read_ptr = 0;

// Default and module parameters
static int buffer_size = 10000;
static int producers = 0;
static int consumers = 0;
static int unique_id = 0;
module_param(buffer_size, int, 0);
module_param(producers, int, 0);
module_param(consumers, int, 0);
module_param(unique_id, int, 0);

// Buffer to store items
int item_buffer[10000];

// Producer function
static int producer(void *param) {
    int item = 2;
    int i;

    for (i = 0; i < buffer_size; i++) {
        // Acquire the mutex before producing an item
        if (down_interruptible(&sem_mutex))
            return -EINTR;

        printk(KERN_INFO "Produced Item#-%d at buffer index:%d for PID:%d\n", item, buffer_write_ptr, *((int *) param));
        
        // Produce the item and update the buffer pointer
        item_buffer[buffer_write_ptr] = item;
        buffer_write_ptr = (buffer_write_ptr + 1) % buffer_size;

        // Release the mutex
        up(&sem_mutex);
    }
    return 0;
}

// Module initialization function
static int __init initialize_module(void) {
    printk(KERN_INFO "Initializing module with buffer_size = %d, producers = %d, consumers = %d, unique_id = %d\n", 
           buffer_size, producers, consumers, unique_id);

    // Initialize the semaphores
    sema_init(&sem_empty, buffer_size);
    sema_init(&sem_full, 0);
    sema_init(&sem_mutex, 1);

    // Set thread parameters
    strncpy(thread_data[0].name, "producer thread 1", 18);
    strncpy(thread_data[1].name, "consumer thread 2", 18);
    thread_data[0].thread_id = unique_id;
    thread_data[1].thread_id = unique_id;

    // Create and start the producer kernel thread if `producers` is set
    if (producers != 0) {
        kernel_threads[0] = kthread_run(producer, (void*)&thread_data[0], "producer_kernel_thread");
    }

    return 0;
}

// Module exit function
static void __exit exit_module_cleanup(void) {
    // Stop the producer thread if it's running
    if (kernel_threads[0]) {
        kthread_stop(kernel_threads[0]);
    }

    printk(KERN_INFO "Exited module");
}

// Specify the module initialization and exit functions
module_init(initialize_module);
module_exit(exit_module_cleanup);

