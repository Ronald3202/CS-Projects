﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Serialization;
using System.ServiceModel;
using System.Text;

namespace final_assignment
{
    // NOTE: You can use the "Rename" command on the "Refactor" menu to change the class name "MoneyTransfer" in code, svc and config file together.
    // NOTE: In order to launch WCF Test Client for testing this service, please select MoneyTransfer.svc or MoneyTransfer.svc.cs at the Solution Explorer and start debugging.
    public class MoneyTransfer : IMoneyTransfer
    {

        public double WithdrawlMoney(string account, double amount, double total)
        {

            //if (string.IsNullOrWhiteSpace(account))
            //{
            //    // subtract amount


            //}

            return total - amount;

        }

        public double CheckBalance(string accountNumber)
        {
            // Simulate balance check logic
            Console.WriteLine($"Checking balance for account {accountNumber}.");
            return 1000.00;
        }
    }
}
