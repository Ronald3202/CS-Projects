﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Xml;
using System.Xml.Linq;

namespace final_assignment
{
    public partial class MemberInfo : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            if (!IsPostBack)
            {
                // Ensure the user is authenticated
                string username = Session["Username"]?.ToString();
                if (string.IsNullOrEmpty(username))
                {
                    Response.Redirect("Member.aspx");
                }

                // Display user information
                lblUsername.Text = username;
                LoadUserBalance(username);
            }
        }

        private void LoadUserBalance(string username)
        {
            try
            {
                string xmlPath = Server.MapPath(Path.Combine(AppDomain.CurrentDomain.BaseDirectory, "Member.xml"));
                XDocument xml = XDocument.Load(xmlPath);

                var user = FindUserInXml(xml, username);
                if (user != null)
                {
                    decimal balance = decimal.Parse(user.Element("Balance")?.Value ?? "0.00");
                    lblBalance.Text = balance.ToString("0.00");
                }
                else
                {
                    lblBalance.Text = "User not found!";
                }
            }
            catch (Exception ex)
            {
                lblBalance.Text = "Error loading balance: " + ex.Message;
            }
        }

        private XElement FindUserInXml(XDocument xml, string username)
        {
            return xml.Root?.Element("Users")?
                .Elements("User")
                .FirstOrDefault(user => user.Element("Username")?.Value == username);
        }

        protected void btnLogout_Click(object sender, EventArgs e)
        {
            Session.Clear();
            Response.Redirect("Member.aspx");
        }

    }
}