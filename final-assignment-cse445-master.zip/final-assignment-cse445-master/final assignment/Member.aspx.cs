﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Xml;
using System.Security.Cryptography;
using System.Text;
using System.IO;
using System.Drawing.Imaging;
using System.Drawing;
using static System.Net.Mime.MediaTypeNames;
using System.Data.SqlClient;

namespace final_assignment
{
    public partial class Member : System.Web.UI.Page
    {

        private string captchaSessionKey = "CaptchaCode";

        protected void Page_Load(object sender, EventArgs e)
        {
            if (!IsPostBack)
            {
                GenerateCaptcha();
            }
        }

        protected void btnLogin_Click(object sender, EventArgs e)
        {
            string username = txtUsername.Text;
            string password = txtPassword.Text;

            if (AuthenticateUser(username, password))
            {
                Session["User"] = username;
                Response.Redirect("MemberPage.aspx");
            }
            else
            {
                lblLoginMessage.Text = "Invalid username or password.";
            }
        }

        protected void btnRegister_Click(object sender, EventArgs e)
        {
            string username = txtNewUsername.Text;
            string password = txtNewPassword.Text;
            string enteredCaptcha = txtCaptcha.Text.Trim();
            string actualCaptcha = Session[captchaSessionKey]?.ToString();

            if (string.IsNullOrEmpty(enteredCaptcha) || actualCaptcha != enteredCaptcha)
            {
                lblCaptchaError.Text = "Invalid CAPTCHA. Please try again.";
                GenerateCaptcha();
                return;
            }

            lblCaptchaError.Text = string.Empty;
            lblRegisterMessage.Text = "Registration successful!";

            string hashedPassword = HashPassword(password);
            AddUserToXml(username, hashedPassword);
            Response.Redirect("Member.aspx");
        }

        private bool AuthenticateUser(string username, string password)
        {
            XmlDocument doc = new XmlDocument();
            doc.Load(Path.Combine(AppDomain.CurrentDomain.BaseDirectory, "Member.xml"));
            foreach (XmlNode node in doc.DocumentElement.ChildNodes)
            {
                if (node["Username"].InnerText == username && node["Password"].InnerText == HashPassword(password))
                {
                    return true;
                }
            }
            return false;
        }

        private string HashPassword(string password)
        {
            using (SHA256 sha = SHA256.Create())
            {
                byte[] data = sha.ComputeHash(Encoding.UTF8.GetBytes(password));
                return Convert.ToBase64String(data);
            }
        }

        private void AddUserToXml(string username, string hashedPassword)
        {
            XmlDocument doc = new XmlDocument();
            doc.Load(Path.Combine(AppDomain.CurrentDomain.BaseDirectory, "Member.xml"));
            XmlNode newUser = doc.CreateElement("Member");
            XmlNode usernameNode = doc.CreateElement("Username");
            usernameNode.InnerText = username;
            XmlNode passwordNode = doc.CreateElement("Password");
            passwordNode.InnerText = hashedPassword;
            XmlNode balanceNode = doc.CreateElement("Balance");
            balanceNode.InnerText = "0";
            newUser.AppendChild(usernameNode);
            newUser.AppendChild(passwordNode);
            newUser.AppendChild(balanceNode);
            doc.DocumentElement.AppendChild(newUser);
            doc.Save(Path.Combine(AppDomain.CurrentDomain.BaseDirectory, "Member.xml"));
        }

        private void GenerateCaptcha()
        {
            // Generate a random string for the CAPTCHA
            string captchaCode = Guid.NewGuid().ToString("N").Substring(0, 6);
            Session[captchaSessionKey] = captchaCode;

            // Create CAPTCHA image
            using (Bitmap bitmap = new Bitmap(200, 50))
            using (Graphics g = Graphics.FromImage(bitmap))
            {
                g.Clear(Color.White);
                using (Font font = new Font("Arial", 20, FontStyle.Bold | FontStyle.Italic))
                {
                    g.DrawString(captchaCode, font, Brushes.Black, new PointF(10, 10));
                }

                // Save image
                using (MemoryStream ms = new MemoryStream())
                {
                    bitmap.Save(ms, ImageFormat.Png);
                    byte[] imageBytes = ms.ToArray();

                    // Convert to Base64 string and set as image source
                    string base64Image = Convert.ToBase64String(imageBytes);
                    captchaImage.ImageUrl = $"data:image/png;base64,{base64Image}";
                }
            }
        }
    }
}