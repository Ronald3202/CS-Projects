﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Runtime.CompilerServices;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Xml;
using static System.Net.Mime.MediaTypeNames;

namespace final_assignment
{
    public partial class Staff : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {

        }

        protected void btnLogin_Click(object sender, EventArgs e)
        {

            // debugging
            //ClientScript.RegisterStartupScript(this.GetType(), "ConsoleLog", $"console.log('{text}');", true);

            XmlDocument staff = new XmlDocument();
            staff.Load(Path.Combine(AppDomain.CurrentDomain.BaseDirectory, "Staff.xml"));

            List<string> usernames = new List<string>();
            List<string> passwords = new List<string>();

            // Parse through the XML and extract usernames and passwords
            XmlNodeList staffNodes = staff.SelectNodes("/StaffMembers/Staff");
            foreach (XmlNode staffNode in staffNodes)
            {
                string un = staffNode.SelectSingleNode("Username")?.InnerText;
                string pw = staffNode.SelectSingleNode("Password")?.InnerText;

                if (un != null && pw != null)
                {
                    usernames.Add(un);
                    passwords.Add(pw);
                }
            }

            // get the username and password
            string username = txtUsername.Text;
            string password = txtPassword.Text;
            int count = 0;
            foreach (string un in usernames)
            {
                if (username == un)
                {
                    if (passwords[count] == password)
                    {
                        // TODO: direct to a new aspx 
                        ClientScript.RegisterStartupScript(this.GetType(), "ConsoleLog", $"console.log('SUCCESS');", true);
                        
                    }
                    else
                    {
                        //ClientScript.RegisterStartupScript(this.GetType(), "ConsoleLog", $"console.log('FAIL');", true);
                        Response.Redirect("Default.aspx");
                    }
                }


                count++;
            }

        }
    }
}