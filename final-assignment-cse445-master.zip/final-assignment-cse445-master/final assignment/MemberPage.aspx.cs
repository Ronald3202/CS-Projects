﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Xml;
using System.Xml.Linq;

namespace final_assignment
{
    public partial class MemberPage : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            if (!IsPostBack)
            {
                string username = Session["Username"]?.ToString();
                if (string.IsNullOrEmpty(username))
                {
                    Response.Redirect("Member.aspx");
                }

                LoadUserBalance(username);
            }
        }

        private void LoadUserBalance(string username)
        {
            try
            {
                string xmlPath = Server.MapPath(Path.Combine(AppDomain.CurrentDomain.BaseDirectory, "Member.xml"));
                XDocument xml = XDocument.Load(xmlPath);

                var user = FindUserInXml(xml, username);
                if (user != null)
                {
                    decimal balance = decimal.Parse(user.Element("Balance")?.Value ?? "0.00");
                    lblBalance.Text = balance.ToString("0.00");
                }
                else
                {
                    lblBalance.Text = "User not found!";
                }
            }
            catch (Exception ex)
            {
                lblBalance.Text = "Error loading balance: " + ex.Message;
            }
        }

        private XElement FindUserInXml(XDocument xml, string username)
        {
            return xml.Root?.Elements("Member")
                .FirstOrDefault(member => member.Element("Username")?.Value == username);
        }

        protected void btnDeposit_Click(object sender, EventArgs e)
        {
            UpdateBalance(decimal.Parse(txtAmount.Text), isDeposit: true);
        }

        protected void btnWithdraw_Click(object sender, EventArgs e)
        {
            UpdateBalance(decimal.Parse(txtAmount.Text), isDeposit: false);
        }

        private void UpdateBalance(decimal amount, bool isDeposit)
        {
            try
            {
                string username = Session["Username"]?.ToString();
                string xmlPath = Server.MapPath(Path.Combine(AppDomain.CurrentDomain.BaseDirectory, "Member.xml"));
                XDocument xml = XDocument.Load(xmlPath);

                var user = FindUserInXml(xml, username);
                if (user != null)
                {
                    decimal currentBalance = decimal.Parse(user.Element("Balance")?.Value ?? "0.00");
                    decimal newBalance = isDeposit ? currentBalance + amount : currentBalance - amount;

                    // Prevent negative balances
                    if (newBalance < 0)
                    {
                        lblBalance.Text = "Insufficient funds.";
                        return;
                    }

                    user.Element("Balance").Value = newBalance.ToString("0.00");
                    xml.Save(xmlPath);

                    lblBalance.Text = newBalance.ToString("0.00");
                }
            }
            catch (Exception ex)
            {
                lblBalance.Text = "Error updating balance: " + ex.Message;
            }
        }

        protected void btnMemberInfo_Click(object sender, EventArgs e)
        {
            Response.Redirect("MemberInfo.aspx");
        }

        protected void btnLogout_Click(object sender, EventArgs e)
        {
            Session.Clear();
            Response.Redirect("Member.aspx");
        }
    }
}