﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace final_assignment
{
    public partial class MoneyTransferTryIt : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {

        }

        protected void tryit(object sender, EventArgs e)
        {
            double amount = Convert.ToDouble(txtWithdrawAmount.Text);
            double total = Convert.ToDouble(lblBalance.Text);

            MoneyTransfer client = new MoneyTransfer();

            lblBalance.Text = Convert.ToString(client.WithdrawlMoney("", amount, total));
        }
    }
}