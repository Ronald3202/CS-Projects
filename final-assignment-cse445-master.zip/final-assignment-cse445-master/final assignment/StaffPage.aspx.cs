﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Xml;

namespace final_assignment
{
    public partial class StaffPage : System.Web.UI.Page
    {

        private int currentPage = 0;
        private int totalPages = 0;

        private List<string> usernames = new List<string>();
        private List<string> passwords = new List<string>();
        private List<string> balances = new List<string>();

        protected void Page_Load(object sender, EventArgs e)
        { 
            // Example: Initialize the table with default data on first load
            tbl_AddRow(cell1Text: "Username", cell2Text: "Password", cell3Text: "Balance", isHeader: true);

            // get the member xml and store
            XmlDocument members = new XmlDocument();
            members.Load(Path.Combine(AppDomain.CurrentDomain.BaseDirectory, "Member.xml"));

            // Parse through the XML and extract usernames passwords and balances
            XmlNodeList memberNodes = members.SelectNodes("/Members/Member");
            foreach (XmlNode memberNode in memberNodes)
            {
                string un = memberNode.SelectSingleNode("Username")?.InnerText;
                string pw = memberNode.SelectSingleNode("Password")?.InnerText;
                string bl = memberNode.SelectSingleNode("Balance")?.InnerText;

                if (un != null && pw != null && bl != null)
                {
                    usernames.Add(un);
                    passwords.Add(pw);
                    balances.Add(bl);
                }
            }

            tbl_AddRow(cell1Text: usernames[0], cell2Text: passwords[0], cell3Text: balances[0], isHeader: false);

            currentPage = 0;
            totalPages = usernames.Count;


        }
        protected void btn_Next(object sender, EventArgs e)
        {

            
            // anti bug if statement
            if (currentPage < totalPages)
            {

                // clear the table
                tblmember.Rows.Clear();

                // re-add header row
                tbl_AddRow(cell1Text: "Username", cell2Text: "Password", cell3Text: "Balance", isHeader: true);


                currentPage++;
                tbl_AddRow(
                    cell1Text: usernames[currentPage],
                    cell2Text: passwords[currentPage],
                    cell3Text: balances[currentPage],
                    isHeader: false);
            }
            
        }

        protected void btn_Previous(object sender, EventArgs e)
        {


            // anti bug if statement
            if (currentPage > 0)
            {
                // clear the table
                tblmember.Rows.Clear();

                // re-add header row
                tbl_AddRow(cell1Text: "Username", cell2Text: "Password", cell3Text: "Balance", isHeader: true);

                currentPage--;
                tbl_AddRow(
                    cell1Text: usernames[currentPage],
                    cell2Text: passwords[currentPage],
                    cell3Text: balances[currentPage],
                    isHeader: false);
            }

        }

        protected void tbl_AddRow(string cell1Text, string cell2Text, string cell3Text, bool isHeader = false)
        {
            TableRow row = new TableRow();

            TableCell cell1 = new TableCell
            {
                Text = cell1Text
            };
            if (isHeader) cell1.Font.Bold = true;
            row.Cells.Add(cell1);

            TableCell cell2 = new TableCell
            {
                Text = cell2Text
            };
            if (isHeader) cell2.Font.Bold = true;
            row.Cells.Add(cell2);

            TableCell cell3 = new TableCell
            {
                Text = cell3Text
            };
            if (isHeader) cell3.Font.Bold = true;
            row.Cells.Add(cell3);

            tblmember.Rows.Add(row); // Ensure 'MyTable' is the correct ID of your table
        }
    }
}