﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace final_assignment
{
    public partial class Default : Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            if (!IsPostBack)
            {
                // Create a new cookie for storing user profile data
                HttpCookie userCookie = new HttpCookie("UserProfile");

                // Add profile information to the cookie
                userCookie["Username"] = "example";

                // Set cookie expiration to 7 days from now
                userCookie.Expires = DateTime.Now.AddDays(7);

                // Add the cookie to the response
                Response.Cookies.Add(userCookie);

                // Save part of the data in Session state for quick server-side access
                Session["Username"] = "example";

                // Debug message
                System.Diagnostics.Debug.WriteLine("Cookie and Session created.");
            }
        }

        protected void Retrieve_Cookie(object sender, EventArgs e)
        {
            // Retrieve user data from the cookie
            HttpCookie userCookie = Request.Cookies["UserProfile"];
            if (userCookie != null)
            {
                string username = userCookie["Username"];

                // Display the retrieved values
                Response.Write($"Cookie - Username: {username}");
            }
            else
            {
                Response.Write("No cookie found.");
            }

            // Retrieve data from Session state
            string sessionUsername = Session["Username"]?.ToString();
            if (sessionUsername != null)
            {
                Response.Write($"<br/>Session - Username: {sessionUsername}");
            }
            else
            {
                Response.Write("<br/>No session data found.");
            }
        }

        protected void UpdateCookie_Click(object sender, EventArgs e)
        {
            HttpCookie userCookie = Request.Cookies["UserProfile"];
            if (userCookie != null)
            {
                userCookie.Expires = DateTime.Now.AddDays(7); // Extend expiration
                Response.Cookies.Add(userCookie);

                Response.Write("Cookie updated.");
            }
        }

        protected void DeleteCookie_Click(object sender, EventArgs e)
        {
            HttpCookie userCookie = new HttpCookie("UserProfile");
            userCookie.Expires = DateTime.Now.AddDays(-1); // Expired
            Response.Cookies.Add(userCookie);

            Response.Write("Cookie deleted.");
        }

        protected void Cookie_Fallback(object sender, EventArgs e)
        {
            string username;

            // Try retrieving from Cookie
            HttpCookie userCookie = Request.Cookies["UserProfile"];
            if (userCookie != null)
            {
                username = userCookie["Username"];
            }
            else
            {
                // Fallback to Session state
                username = Session["Username"]?.ToString();
            }

            if (!string.IsNullOrEmpty(username))
            {
                Response.Write($"Welcome, {username}");
            }
            else
            {
                Response.Write("User data not found.");
            }
        }




        protected void btnMember_Click(object sender, EventArgs e)
        {
            Response.Redirect("Member.aspx"); 
        }

        protected void btnStaff_Click(object sender, EventArgs e)
        {
            Response.Redirect("Staff.aspx"); 
        }

        protected void btnTryService_Click(object sender, EventArgs e)
        {
            Response.Redirect("MoneyTransferTryIt.aspx");


        }
    }
}