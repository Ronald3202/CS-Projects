/*
 * Copyright (C) Rida Bazzi, 2017
 *
 * Do not share this file with anyone
 */
#include <cstdio>
#include <cstdlib>
#include <cstdarg>
#include <cctype>
#include <cstring>
#include <string>
#include <iostream>
#include "execute.h"

using namespace std;

#define DEBUG 1     // 1 => Turn ON debugging, 0 => Turn OFF debugging

int mem[1000];
int next_available = 0;

std::vector<int> inputs;
int next_input = 0;

void debug(const char* format, ...)
{
    va_list args;
    if (DEBUG)
    {
        va_start (args, format);
        vfprintf (stdout, format, args);
        va_end (args);
    }
}

void execute_program(struct InstructionNode * program)
{
    struct InstructionNode * programCounter = program;
    int operator1, operator2, operationResult;

    while(programCounter != NULL)
    {
        switch(programCounter->type)
        {
            case NOOP:
                programCounter = programCounter->next;
                break;
            case IN:
                mem[programCounter->input_inst.var_index] = inputs[next_input];
                next_input++;
                programCounter = programCounter->next;
                break;
            case OUT:
                printf("%d ", mem[programCounter->output_inst.var_index]);
                fflush(stdin);
                programCounter = programCounter->next;
                break;
            case ASSIGN:
                switch(programCounter->assign_inst.op)
                {
                    case OPERATOR_PLUS:
                        operator1 = mem[programCounter->assign_inst.operand1_index];
                        operator2 = mem[programCounter->assign_inst.operand2_index];
                        operationResult = operator1 + operator2;
                        break;
                    case OPERATOR_MINUS:
                        operator1 = mem[programCounter->assign_inst.operand1_index];
                        operator2 = mem[programCounter->assign_inst.operand2_index];
                        operationResult = operator1 - operator2;
                        break;
                    case OPERATOR_MULT:
                        operator1 = mem[programCounter->assign_inst.operand1_index];
                        operator2 = mem[programCounter->assign_inst.operand2_index];
                        operationResult = operator1 * operator2;
                        break;
                    case OPERATOR_DIV:
                        operator1 = mem[programCounter->assign_inst.operand1_index];
                        operator2 = mem[programCounter->assign_inst.operand2_index];
                        operationResult = operator1 / operator2;
                        break;
                    case OPERATOR_NONE:
                        operator1 = mem[programCounter->assign_inst.operand1_index];
                        operationResult = operator1;
                        break;
                }
                mem[programCounter->assign_inst.left_hand_side_index] = operationResult;
                programCounter = programCounter->next;
                break;
            case CJMP:
                if (programCounter->cjmp_inst.target == NULL)
                {
                    debug("Error: programCounter->cjmp_inst->target is null.\n");
                    exit(1);
                }
                operator1 = mem[programCounter->cjmp_inst.operand1_index];
                operator2 = mem[programCounter->cjmp_inst.operand2_index];
                switch(programCounter->cjmp_inst.condition_op)
                {
                    case CONDITION_GREATER:
                        if(operator1 > operator2)
                            programCounter = programCounter->next;
                        else
                            programCounter = programCounter->cjmp_inst.target;
                        break;
                    case CONDITION_LESS:
                        if(operator1 < operator2)
                            programCounter = programCounter->next;
                        else
                            programCounter = programCounter->cjmp_inst.target;
                        break;
                    case CONDITION_NOTEQUAL:
                        if(operator1 != operator2)
                            programCounter = programCounter->next;
                        else
                            programCounter = programCounter->cjmp_inst.target;
                        break;
                }
                break;
            case JMP:
                if (programCounter->jmp_inst.target == NULL)
                {
                    debug("Error: programCounter->jmp_inst->target is null.\n");
                    exit(1);
                }
                programCounter = programCounter->jmp_inst.target;
                break;
            default:
                debug("Error: invalid value for programCounter->type (%d).\n", programCounter->type);
                exit(1);
                break;
        }
    }
}

int main()
{
    struct InstructionNode * program;
    program = parse_generate_intermediate_representation();
    execute_program(program);
    return 0;
}
