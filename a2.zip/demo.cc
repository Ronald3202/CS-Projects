/*
* Ronald Lin
*/

#include <vector>
#include <string>
#include <iostream>
#include "execute.h"
#include "lexer.h"

using namespace std;

LexicalAnalyzer lexer;

Token nextToken;
Token tmpToken;
struct InstructionNode *node = new InstructionNode();
struct InstructionNode *tmpNode;

vector<string> memLocations;

void shiftNode() {
    tmpNode->next = new InstructionNode;
    tmpNode = tmpNode->next;
}

void handleSemiColon(){

}

struct InstructionNode *IfLoop() {
    tmpToken = lexer.GetToken();
    while (tmpToken.token_type != RBRACE) {
        switch (tmpToken.token_type) {
            case INPUT: {
                tmpNode->type = IN;

                nextToken = lexer.GetToken();
                for (int i = 0; i < memLocations.size(); i++) {
                    if (nextToken.lexeme == memLocations[i]) {
                        tmpNode->input_inst.var_index = i;
                    }
                }
                shiftNode();
                break;
            }
            case OUTPUT: {
                tmpNode->type = OUT;
                nextToken = lexer.GetToken();
                for (int i = 0; i < memLocations.size(); i++) {
                    if (nextToken.lexeme == memLocations[i]) {
                        tmpNode->input_inst.var_index = i;
                    }
                }
                shiftNode();
                break;
            }
            case ID: {
                tmpNode->type = ASSIGN;
                bool opSet = false;

                for (int i = 0; i < memLocations.size(); i++) {
                    if (tmpToken.lexeme == memLocations[i]) {
                        tmpNode->assign_inst.left_hand_side_index = i;
                    }
                }

                nextToken = lexer.GetToken();
                bool opCount = true;

                while (nextToken.token_type != SEMICOLON) {
                    if (nextToken.token_type == ID) {
                        for (int i = 0; i < memLocations.size(); i++) {
                            if (nextToken.lexeme == memLocations[i]) {
                                if (opCount) {
                                    tmpNode->assign_inst.operand1_index = i;
                                    opCount = false;
                                } else {
                                    tmpNode->assign_inst.operand2_index = i;
                                }
                            }
                        }
                    } else if (nextToken.token_type == NUM) {
                        int num = stoi(nextToken.lexeme);
                        int memIndex;
                        bool found = false;

                        for (int i = 0; i < memLocations.size(); i++) {
                            if (nextToken.lexeme == memLocations[i]) {
                                memIndex = i;
                                found = true;
                            }
                        }

                        if (!found) {
                            memIndex = next_available;
                            mem[next_available] = num;
                            memLocations.push_back(nextToken.lexeme);
                            next_available++;
                        }

                        if (opCount) {
                            tmpNode->assign_inst.operand1_index = memIndex;
                            opCount = false;
                        } else {
                            tmpNode->assign_inst.operand2_index = memIndex;
                        }
                    } else if (nextToken.token_type == PLUS) {
                        tmpNode->assign_inst.op = OPERATOR_PLUS;
                        opSet = true;
                    } else if (nextToken.token_type == MINUS) {
                        tmpNode->assign_inst.op = OPERATOR_MINUS;
                        opSet = true;
                    } else if (nextToken.token_type == DIV) {
                        tmpNode->assign_inst.op = OPERATOR_DIV;
                        opSet = true;
                    } else if (nextToken.token_type == MULT) {
                        tmpNode->assign_inst.op = OPERATOR_MULT;
                        opSet = true;
                    }
                    nextToken = lexer.GetToken();
                }

                if (!opSet) {
                    tmpNode->assign_inst.op = OPERATOR_NONE;
                }

                shiftNode();
                break;
            }
            case IF: {
                tmpNode->type = CJMP;
                bool op1Set = false;
                nextToken = lexer.GetToken();
                while (nextToken.token_type != LBRACE) {
                    if (nextToken.token_type == ID) {
                        for (int i = 0; i < memLocations.size(); i++) {
                            if (nextToken.lexeme == memLocations[i]) {
                                if (!op1Set) {
                                    tmpNode->assign_inst.operand1_index = i;
                                    op1Set = true;
                                } else {
                                    tmpNode->assign_inst.operand2_index = i;
                                }
                            }
                        }
                    } else {
                        switch (nextToken.token_type) {
                            case NOTEQUAL:
                                tmpNode->cjmp_inst.condition_op = CONDITION_NOTEQUAL;
                                break;
                            case GREATER:
                                tmpNode->cjmp_inst.condition_op = CONDITION_GREATER;
                                break;
                            case LESS:
                                tmpNode->cjmp_inst.condition_op = CONDITION_LESS;
                                break;
                            default:
                                break;
                        }
                    }
                    nextToken = lexer.GetToken();
                }
                InstructionNode *currentNode = tmpNode;
                InstructionNode *buffNode;
                shiftNode();
                buffNode = IfLoop();
                if (buffNode->type < 1000 || buffNode->type > 1005) {
                    buffNode->type = NOOP;
                }
                currentNode->cjmp_inst.target = buffNode;

                tmpNode->type = NOOP;
                tmpNode->next = new InstructionNode;
                tmpNode = tmpNode->next;
                break;
            }
            case WHILE: {
                tmpNode->type = CJMP;
                bool op1Set = false;
                nextToken = lexer.GetToken();
                while (nextToken.token_type != LBRACE) {
                    if (nextToken.token_type == ID) {
                        for (int i = 0; i < memLocations.size(); i++) {
                            if (nextToken.lexeme == memLocations[i]) {
                                if (!op1Set) {
                                    tmpNode->assign_inst.operand1_index = i;
                                    op1Set = true;
                                } else {
                                    tmpNode->assign_inst.operand2_index = i;
                                }
                            }
                        }
                    } else if (nextToken.token_type == NUM) {
                        int num = stoi(nextToken.lexeme);
                        int memIndex;
                        bool found = false;

                        for (int i = 0; i < memLocations.size(); i++) {
                            if (nextToken.lexeme == memLocations[i]) {
                                memIndex = i;
                                found = true;
                            }
                        }

                        if (!found) {
                            memIndex = next_available;
                            mem[next_available] = num;
                            memLocations.push_back(nextToken.lexeme);
                            next_available++;
                        }

                        if (!op1Set) {
                            tmpNode->assign_inst.operand1_index = memIndex;
                            op1Set = true;
                        } else {
                            tmpNode->assign_inst.operand2_index = memIndex;
                        }
                    } else {
                        switch (nextToken.token_type) {
                            case NOTEQUAL:
                                tmpNode->cjmp_inst.condition_op = CONDITION_NOTEQUAL;
                                break;
                            case GREATER:
                                tmpNode->cjmp_inst.condition_op = CONDITION_GREATER;
                                break;
                            case LESS:
                                tmpNode->cjmp_inst.condition_op = CONDITION_LESS;
                                break;
                            default:
                                break;
                        }
                    }
                    nextToken = lexer.GetToken();
                }

                InstructionNode *currentNode = tmpNode;
                InstructionNode *buffNode;
                shiftNode();
                buffNode = IfLoop();

                if (buffNode->type < 1000 || buffNode->type > 1005) {
                    buffNode->type = JMP;
                    buffNode->jmp_inst.target = currentNode;
                }

                shiftNode();
                tmpNode->type = NOOP;
                currentNode->cjmp_inst.target = tmpNode;

                shiftNode();
                break;
            }
            case FOR: {

                // Sets up the assign statement within the for loop
                tmpNode->type = ASSIGN;
                bool opSet = false;
                nextToken = lexer.GetToken();

                while (nextToken.token_type == LPAREN) {
                    nextToken = lexer.GetToken();
                }

                for (int i = 0; i < memLocations.size(); i++) {
                    if (nextToken.lexeme == memLocations[i]) {
                        tmpNode->assign_inst.left_hand_side_index = i;
                    }
                }
                bool opCount = true;
                nextToken = lexer.GetToken();
                while (nextToken.token_type != SEMICOLON) {
                    if (nextToken.token_type == ID) {
                        for (int i = 0; i < memLocations.size(); i++) {
                            if (nextToken.lexeme == memLocations[i]) {
                                if (opCount) {
                                    tmpNode->assign_inst.operand1_index = i;
                                    opCount = false;
                                } else {
                                    tmpNode->assign_inst.operand2_index = i;
                                }
                            }
                        }
                    } else if (nextToken.token_type == NUM) {
                        int num = stoi(nextToken.lexeme);
                        int memIndex;
                        bool found = false;

                        for (int i = 0; i < memLocations.size(); i++) {
                            if (nextToken.lexeme == memLocations[i]) {
                                memIndex = i;
                                found = true;
                            }
                        }

                        if (!found) {
                            memIndex = next_available;
                            mem[next_available] = num;
                            memLocations.push_back(nextToken.lexeme);
                            next_available++;
                        }

                        if (opCount) {
                            tmpNode->assign_inst.operand1_index = memIndex;
                            opCount = false;
                        } else {
                            tmpNode->assign_inst.operand2_index = memIndex;
                        }
                    } else if (nextToken.token_type == PLUS) {
                        tmpNode->assign_inst.op = OPERATOR_PLUS;
                        opSet = true;
                    } else if (nextToken.token_type == MINUS) {
                        tmpNode->assign_inst.op = OPERATOR_MINUS;
                        opSet = true;
                    } else if (nextToken.token_type == DIV) {
                        tmpNode->assign_inst.op = OPERATOR_DIV;
                        opSet = true;
                    } else if (nextToken.token_type == MULT) {
                        tmpNode->assign_inst.op = OPERATOR_MULT;
                        opSet = true;
                    }
                    nextToken = lexer.GetToken();
                }

                if (!opSet) {
                    tmpNode->assign_inst.op = OPERATOR_NONE;
                }

                shiftNode();

                // The start of setting up the for loop statement
                nextToken = lexer.GetToken();
                tmpNode->type = CJMP;
                bool op1Set = false;
                while (nextToken.token_type != SEMICOLON) {
                    if (nextToken.token_type == ID) {
                        for (int i = 0; i < memLocations.size(); i++) {
                            if (nextToken.lexeme == memLocations[i]) {
                                if (!op1Set) {
                                    tmpNode->assign_inst.operand1_index = i;
                                    op1Set = true;
                                } else {
                                    tmpNode->assign_inst.operand2_index = i;
                                }
                            }
                        }
                    } else if (nextToken.token_type == NUM) {
                        int num = stoi(nextToken.lexeme);
                        int memIndex;
                        bool found = false;

                        for (int i = 0; i < memLocations.size(); i++) {
                            if (nextToken.lexeme == memLocations[i]) {
                                memIndex = i;
                                found = true;
                            }
                        }

                        if (!found) {
                            memIndex = next_available;
                            mem[next_available] = num;
                            memLocations.push_back(nextToken.lexeme);
                            next_available++;
                        }

                        if (!op1Set) {
                            tmpNode->assign_inst.operand1_index = memIndex;
                            op1Set = true;
                        } else {
                            tmpNode->assign_inst.operand2_index = memIndex;
                        }
                    } else {
                        switch (nextToken.token_type) {
                            case NOTEQUAL:
                                tmpNode->cjmp_inst.condition_op = CONDITION_NOTEQUAL;
                                break;
                            case GREATER:
                                tmpNode->cjmp_inst.condition_op = CONDITION_GREATER;
                                break;
                            case LESS:
                                tmpNode->cjmp_inst.condition_op = CONDITION_LESS;
                                break;
                            default:
                                break;
                        }
                    }
                    nextToken = lexer.GetToken();
                }

                InstructionNode *loopCurrentNode = tmpNode;

                nextToken = lexer.GetToken();
                // Starting of setting the increment statement
                InstructionNode *incrementStatement = new InstructionNode;
                incrementStatement->type = ASSIGN;
                opSet = false;

                for (int i = 0; i < memLocations.size(); i++) {
                    if (nextToken.lexeme == memLocations[i]) {
                        incrementStatement->assign_inst.left_hand_side_index = i;
                    }
                }

                nextToken = lexer.GetToken();
                while (nextToken.token_type == EQUAL) {
                    nextToken = lexer.GetToken();
                }
                opCount = true;

                while (nextToken.token_type != SEMICOLON) {
                    if (nextToken.token_type == ID) {
                        for (int i = 0; i < memLocations.size(); i++) {
                            if (nextToken.lexeme == memLocations[i]) {
                                if (opCount) {
                                    incrementStatement->assign_inst.operand1_index = i;
                                    opCount = false;
                                } else {
                                    incrementStatement->assign_inst.operand2_index = i;
                                }
                            }
                        }
                    } else if (nextToken.token_type == NUM) {
                        int num = stoi(nextToken.lexeme);
                        int memIndex;
                        bool found = false;

                        for (int i = 0; i < memLocations.size(); i++) {
                            if (nextToken.lexeme == memLocations[i]) {
                                memIndex = i;
                                found = true;
                            }
                        }

                        if (!found) {
                            memIndex = next_available;
                            mem[next_available] = num;
                            memLocations.push_back(nextToken.lexeme);
                            next_available++;
                        }

                        if (opCount) {
                            incrementStatement->assign_inst.operand1_index = memIndex;
                            opCount = false;
                        } else {
                            incrementStatement->assign_inst.operand2_index = memIndex;
                        }
                    } else if (nextToken.token_type == PLUS) {
                        incrementStatement->assign_inst.op = OPERATOR_PLUS;
                        opSet = true;
                    } else if (nextToken.token_type == MINUS) {
                        incrementStatement->assign_inst.op = OPERATOR_MINUS;
                        opSet = true;
                    } else if (nextToken.token_type == DIV) {
                        incrementStatement->assign_inst.op = OPERATOR_DIV;
                        opSet = true;
                    } else if (nextToken.token_type == MULT) {
                        incrementStatement->assign_inst.op = OPERATOR_MULT;
                        opSet = true;
                    }
                    nextToken = lexer.GetToken();
                }

                if (!opSet) {
                    incrementStatement->assign_inst.op = OPERATOR_NONE;
                }

                shiftNode();
                tmpNode = IfLoop();

                tmpNode->type = incrementStatement->type;
                tmpNode->assign_inst.left_hand_side_index = incrementStatement->assign_inst.left_hand_side_index;
                tmpNode->assign_inst.op = incrementStatement->assign_inst.op;
                tmpNode->assign_inst.operand1_index = incrementStatement->assign_inst.operand1_index;
                tmpNode->assign_inst.operand2_index = incrementStatement->assign_inst.operand2_index;

                shiftNode();

                tmpNode->type = JMP;
                tmpNode->jmp_inst.target = loopCurrentNode;

                // if(tmpNode->type < 1000 || tmpNode->type > 1005){
                //     tmpNode->type = JMP;
                //     tmpNode->jmp_inst.target = loopCurrentNode;
                // }
                shiftNode();
                tmpNode->type = NOOP;
                loopCurrentNode->cjmp_inst.target = tmpNode;

                shiftNode();
                break;
            }
            case SWITCH: {
                int switchVar;
                nextToken = lexer.GetToken();
                while (nextToken.token_type != LBRACE) {
                    if (nextToken.token_type == ID) {
                        for (int i = 0; i < memLocations.size(); i++) {
                            if (nextToken.lexeme == memLocations[i]) {
                                switchVar = i;
                            }
                        }
                    }
                    nextToken = lexer.GetToken();
                }


                //InstructionNode *ifNode;
                bool first = true;
                vector<InstructionNode *> nodesNeedingNoop;
                while (nextToken.token_type != RBRACE) {
                    while (nextToken.token_type == CASE) {
                        //creating the if 

                        nextToken = lexer.GetToken();
                        tmpNode->type = CJMP;
                        tmpNode->cjmp_inst.condition_op = CONDITION_NOTEQUAL;
                        tmpNode->cjmp_inst.operand1_index = switchVar;
                        if (nextToken.token_type == NUM) {
                            int num = stoi(nextToken.lexeme);
                            int memIndex;
                            bool found = false;

                            for (int i = 0; i < memLocations.size(); i++) {
                                if (nextToken.lexeme == memLocations[i]) {
                                    memIndex = i;
                                    found = true;
                                }
                            }

                            if (!found) {
                                memIndex = next_available;
                                mem[next_available] = num;
                                memLocations.push_back(nextToken.lexeme);
                                next_available++;
                            }
                            tmpNode->cjmp_inst.operand2_index = memIndex;
                            InstructionNode *currentNode = tmpNode;

                            shiftNode();
                            shiftNode();

                            currentNode->cjmp_inst.target = tmpNode;

                            InstructionNode *buffNode;
                            buffNode = IfLoop();
                            tmpNode->type = JMP;
                            nodesNeedingNoop.push_back(tmpNode);
                            shiftNode();
                            currentNode->next = tmpNode;
                        }
                    }
                    while (nextToken.token_type == DEFAULT) {
                        //ifNode->jmp_inst.target = tmpNode;
                        InstructionNode *buffNode;
                        buffNode = IfLoop();
                        tmpNode->type = JMP;
                        nodesNeedingNoop.push_back(tmpNode);
                    }
                    nextToken = lexer.GetToken();
                }
                // need to create the noop that the loops jump to
                tmpNode->type = NOOP;

                for (int i = 0; i < nodesNeedingNoop.size(); i++) {
                    nodesNeedingNoop[i]->jmp_inst.target = tmpNode;
                }
                shiftNode();
                break;
            }
            case END_OF_FILE:
                break;
            case VAR:
                break;
            case CASE:
                break;
            case DEFAULT:
                break;
            case ARRAY:
                break;
            case PLUS:
                break;
            case MINUS:
                break;
            case DIV:
                break;
            case MULT:
                break;
            case EQUAL:
                break;
            case COLON:
                break;
            case COMMA:
                break;
            case SEMICOLON:
                break;
            case LBRAC:
                break;
            case RBRAC:
                break;
            case LPAREN:
                break;
            case RPAREN:
                break;
            case LBRACE:
                break;
            case RBRACE:
                break;
            case NOTEQUAL:
                break;
            case GREATER:
                break;
            case LESS:
                break;
            case NUM:
                break;
            case ERROR:
                break;
        }
        tmpToken = lexer.GetToken();
    }
    return tmpNode;
}

struct InstructionNode *parse_generate_intermediate_representation() {
    Token tmp = lexer.GetToken();
    while (tmp.token_type != SEMICOLON) {
        if (tmp.token_type == ID) {
            mem[next_available] = 0;
            memLocations.push_back(tmp.lexeme);
            next_available++;
        }
        tmp = lexer.GetToken();
    }

    tmpNode = node;
    while (tmp.token_type != RBRACE) {
        switch (tmp.token_type) {
            case INPUT: {
                nextToken = lexer.GetToken();
                tmpNode->type = IN;

                for (int i = 0; i < memLocations.size(); i++) {
                    if (nextToken.lexeme == memLocations[i]) {
                        tmpNode->input_inst.var_index = i;
                    }
                }

                shiftNode();
                break;
            }
            case OUTPUT: {
                nextToken = lexer.GetToken();
                tmpNode->type = OUT;

                for (int i = 0; i < memLocations.size(); i++) {
                    if (nextToken.lexeme == memLocations[i]) {
                        tmpNode->input_inst.var_index = i;
                    }
                }

                shiftNode();
                break;
            }
            case ID: {
                tmpNode->type = ASSIGN;
                bool opSet = false;

                for (int i = 0; i < memLocations.size(); i++) {
                    if (tmp.lexeme == memLocations[i]) {
                        tmpNode->assign_inst.left_hand_side_index = i;
                    }
                }

                nextToken = lexer.GetToken();
                bool opCount = true;

                while (nextToken.token_type != SEMICOLON) {
                    if (nextToken.token_type == ID) {
                        for (int i = 0; i < memLocations.size(); i++) {
                            if (nextToken.lexeme == memLocations[i]) {
                                if (opCount) {
                                    tmpNode->assign_inst.operand1_index = i;
                                    opCount = false;
                                } else {
                                    tmpNode->assign_inst.operand2_index = i;
                                }
                            }
                        }
                    } else if (nextToken.token_type == NUM) {
                        int num = stoi(nextToken.lexeme);
                        int memIndex;
                        bool found = false;

                        for (int i = 0; i < memLocations.size(); i++) {
                            if (nextToken.lexeme == memLocations[i]) {
                                memIndex = i;
                                found = true;
                            }
                        }

                        if (!found) {
                            memIndex = next_available;
                            mem[next_available] = num;
                            memLocations.push_back(nextToken.lexeme);
                            next_available++;
                        }

                        if (opCount) {
                            tmpNode->assign_inst.operand1_index = memIndex;
                            opCount = false;
                        } else {
                            tmpNode->assign_inst.operand2_index = memIndex;
                        }
                    } else if (nextToken.token_type == PLUS) {
                        tmpNode->assign_inst.op = OPERATOR_PLUS;
                        opSet = true;
                    } else if (nextToken.token_type == MINUS) {
                        tmpNode->assign_inst.op = OPERATOR_MINUS;
                        opSet = true;
                    } else if (nextToken.token_type == DIV) {
                        tmpNode->assign_inst.op = OPERATOR_DIV;
                        opSet = true;
                    } else if (nextToken.token_type == MULT) {
                        tmpNode->assign_inst.op = OPERATOR_MULT;
                        opSet = true;
                    }
                    nextToken = lexer.GetToken();
                }

                if (!opSet) {
                    tmpNode->assign_inst.op = OPERATOR_NONE;
                }

                shiftNode();
                break;
            }
            case IF: {
                tmpNode->type = CJMP;
                bool op1Set = false;
                nextToken = lexer.GetToken();
                while (nextToken.token_type != LBRACE) {
                    if (nextToken.token_type == ID) {
                        for (int i = 0; i < memLocations.size(); i++) {
                            if (nextToken.lexeme == memLocations[i]) {
                                if (!op1Set) {
                                    tmpNode->assign_inst.operand1_index = i;
                                    op1Set = true;
                                } else {
                                    tmpNode->assign_inst.operand2_index = i;
                                }
                            }
                        }
                    } else {
                        switch (nextToken.token_type) {
                            case NOTEQUAL:
                                tmpNode->cjmp_inst.condition_op = CONDITION_NOTEQUAL;
                                break;
                            case GREATER:
                                tmpNode->cjmp_inst.condition_op = CONDITION_GREATER;
                                break;
                            case LESS:
                                tmpNode->cjmp_inst.condition_op = CONDITION_LESS;
                                break;
                            default:
                                break;
                        }
                    }
                    nextToken = lexer.GetToken();
                }

                InstructionNode *currentNode = tmpNode;
                InstructionNode *buffNode;
                shiftNode();
                buffNode = IfLoop();
                if (buffNode->type < 1000 || buffNode->type > 1005) {
                    buffNode->type = NOOP;
                }
                currentNode->cjmp_inst.target = buffNode;

                tmpNode->type = NOOP;
                shiftNode();
                break;
            }
            case WHILE: {
                tmpNode->type = CJMP;
                bool op1Set = false;
                nextToken = lexer.GetToken();
                while (nextToken.token_type != LBRACE) {
                    if (nextToken.token_type == ID) {
                        for (int i = 0; i < memLocations.size(); i++) {
                            if (nextToken.lexeme == memLocations[i]) {
                                if (!op1Set) {
                                    tmpNode->assign_inst.operand1_index = i;
                                    op1Set = true;
                                } else {
                                    tmpNode->assign_inst.operand2_index = i;
                                }
                            }
                        }
                    } else if (nextToken.token_type == NUM) {
                        int num = stoi(nextToken.lexeme);
                        int memIndex;
                        bool found = false;

                        for (int i = 0; i < memLocations.size(); i++) {
                            if (nextToken.lexeme == memLocations[i]) {
                                memIndex = i;
                                found = true;
                            }
                        }

                        if (!found) {
                            memIndex = next_available;
                            mem[next_available] = num;
                            memLocations.push_back(nextToken.lexeme);
                            next_available++;
                        }

                        if (!op1Set) {
                            tmpNode->assign_inst.operand1_index = memIndex;
                            op1Set = true;
                        } else {
                            tmpNode->assign_inst.operand2_index = memIndex;
                        }
                    } else {
                        switch (nextToken.token_type) {
                            case NOTEQUAL:
                                tmpNode->cjmp_inst.condition_op = CONDITION_NOTEQUAL;
                                break;
                            case GREATER:
                                tmpNode->cjmp_inst.condition_op = CONDITION_GREATER;
                                break;
                            case LESS:
                                tmpNode->cjmp_inst.condition_op = CONDITION_LESS;
                                break;
                            default:
                                break;
                        }
                    }
                    nextToken = lexer.GetToken();
                }

                InstructionNode *currentNode = tmpNode;
                InstructionNode *buffNode;
                shiftNode();
                buffNode = IfLoop();

                if (buffNode->type < 1000 || buffNode->type > 1005) {
                    buffNode->type = JMP;
                    buffNode->jmp_inst.target = currentNode;
                }

                shiftNode();
                tmpNode->type = NOOP;
                currentNode->cjmp_inst.target = tmpNode;

                shiftNode();
                break;
            }
            case FOR: {
                tmpNode->type = ASSIGN;
                bool opSet = false;
                nextToken = lexer.GetToken();


                while (nextToken.token_type == LPAREN) {
                    nextToken = lexer.GetToken();
                }


                for (int i = 0; i < memLocations.size(); i++) {
                    if (nextToken.lexeme == memLocations[i]) {
                        tmpNode->assign_inst.left_hand_side_index = i;
                    }
                }
                bool opCount = true;
                nextToken = lexer.GetToken();
                while (nextToken.token_type != SEMICOLON) {
                    if (nextToken.token_type == ID) {
                        for (int i = 0; i < memLocations.size(); i++) {
                            if (nextToken.lexeme == memLocations[i]) {
                                if (opCount) {
                                    tmpNode->assign_inst.operand1_index = i;
                                    opCount = false;
                                } else {
                                    tmpNode->assign_inst.operand2_index = i;
                                }
                            }
                        }
                    } else if (nextToken.token_type == NUM) {
                        int num = stoi(nextToken.lexeme);
                        int memIndex;
                        bool found = false;

                        for (int i = 0; i < memLocations.size(); i++) {
                            if (nextToken.lexeme == memLocations[i]) {
                                memIndex = i;
                                found = true;
                            }
                        }

                        if (!found) {
                            memIndex = next_available;
                            mem[next_available] = num;
                            memLocations.push_back(nextToken.lexeme);
                            next_available++;
                        }

                        if (opCount) {
                            tmpNode->assign_inst.operand1_index = memIndex;
                            opCount = false;
                        } else {
                            tmpNode->assign_inst.operand2_index = memIndex;
                        }
                    } else if (nextToken.token_type == PLUS) {
                        tmpNode->assign_inst.op = OPERATOR_PLUS;
                        opSet = true;
                    } else if (nextToken.token_type == MINUS) {
                        tmpNode->assign_inst.op = OPERATOR_MINUS;
                        opSet = true;
                    } else if (nextToken.token_type == DIV) {
                        tmpNode->assign_inst.op = OPERATOR_DIV;
                        opSet = true;
                    } else if (nextToken.token_type == MULT) {
                        tmpNode->assign_inst.op = OPERATOR_MULT;
                        opSet = true;
                    }
                    nextToken = lexer.GetToken();
                }

                if (!opSet) {
                    tmpNode->assign_inst.op = OPERATOR_NONE;
                }

                shiftNode();

                nextToken = lexer.GetToken();
                tmpNode->type = CJMP;
                bool op1Set = false;
                while (nextToken.token_type != SEMICOLON) {
                    if (nextToken.token_type == ID) {
                        for (int i = 0; i < memLocations.size(); i++) {
                            if (nextToken.lexeme == memLocations[i]) {
                                if (!op1Set) {
                                    tmpNode->assign_inst.operand1_index = i;
                                    op1Set = true;
                                } else {
                                    tmpNode->assign_inst.operand2_index = i;
                                }
                            }
                        }
                    } else if (nextToken.token_type == NUM) {
                        int num = stoi(nextToken.lexeme);
                        int memIndex;
                        bool found = false;

                        for (int i = 0; i < memLocations.size(); i++) {
                            if (nextToken.lexeme == memLocations[i]) {
                                memIndex = i;
                                found = true;
                            }
                        }

                        if (!found) {
                            memIndex = next_available;
                            mem[next_available] = num;
                            memLocations.push_back(nextToken.lexeme);
                            next_available++;
                        }

                        if (!op1Set) {
                            tmpNode->assign_inst.operand1_index = memIndex;
                            op1Set = true;
                        } else {
                            tmpNode->assign_inst.operand2_index = memIndex;
                        }
                    } else {
                        switch (nextToken.token_type) {
                            case NOTEQUAL:
                                tmpNode->cjmp_inst.condition_op = CONDITION_NOTEQUAL;
                                break;
                            case GREATER:
                                tmpNode->cjmp_inst.condition_op = CONDITION_GREATER;
                                break;
                            case LESS:
                                tmpNode->cjmp_inst.condition_op = CONDITION_LESS;
                                break;
                            default:
                                break;
                        }
                    }
                    nextToken = lexer.GetToken();
                }

                InstructionNode *loopCurrentNode = tmpNode;

                nextToken = lexer.GetToken();
                // Starting of setting the increment statement
                InstructionNode *incrementStatement = new InstructionNode;
                incrementStatement->type = ASSIGN;
                opSet = false;

                for (int i = 0; i < memLocations.size(); i++) {
                    if (nextToken.lexeme == memLocations[i]) {
                        incrementStatement->assign_inst.left_hand_side_index = i;
                    }
                }

                nextToken = lexer.GetToken();
                while (nextToken.token_type == EQUAL) {
                    nextToken = lexer.GetToken();
                }
                opCount = true;

                while (nextToken.token_type != SEMICOLON) {
                    if (nextToken.token_type == ID) {
                        for (int i = 0; i < memLocations.size(); i++) {
                            if (nextToken.lexeme == memLocations[i]) {
                                if (opCount) {
                                    incrementStatement->assign_inst.operand1_index = i;
                                    opCount = false;
                                } else {
                                    incrementStatement->assign_inst.operand2_index = i;
                                }
                            }
                        }
                    } else if (nextToken.token_type == NUM) {
                        int num = stoi(nextToken.lexeme);
                        int memIndex;
                        bool found = false;

                        for (int i = 0; i < memLocations.size(); i++) {
                            if (nextToken.lexeme == memLocations[i]) {
                                memIndex = i;
                                found = true;
                            }
                        }

                        if (!found) {
                            memIndex = next_available;
                            mem[next_available] = num;
                            memLocations.push_back(nextToken.lexeme);
                            next_available++;
                        }

                        if (opCount) {
                            incrementStatement->assign_inst.operand1_index = memIndex;
                            opCount = false;
                        } else {
                            incrementStatement->assign_inst.operand2_index = memIndex;
                        }
                    } else if (nextToken.token_type == PLUS) {
                        incrementStatement->assign_inst.op = OPERATOR_PLUS;
                        opSet = true;
                    } else if (nextToken.token_type == MINUS) {
                        incrementStatement->assign_inst.op = OPERATOR_MINUS;
                        opSet = true;
                    } else if (nextToken.token_type == DIV) {
                        incrementStatement->assign_inst.op = OPERATOR_DIV;
                        opSet = true;
                    } else if (nextToken.token_type == MULT) {
                        incrementStatement->assign_inst.op = OPERATOR_MULT;
                        opSet = true;
                    }
                    nextToken = lexer.GetToken();
                }

                if (!opSet) {
                    incrementStatement->assign_inst.op = OPERATOR_NONE;
                }

                shiftNode();
                tmpNode = IfLoop();

                tmpNode->type = incrementStatement->type;
                tmpNode->assign_inst.left_hand_side_index = incrementStatement->assign_inst.left_hand_side_index;
                tmpNode->assign_inst.op = incrementStatement->assign_inst.op;
                tmpNode->assign_inst.operand1_index = incrementStatement->assign_inst.operand1_index;
                tmpNode->assign_inst.operand2_index = incrementStatement->assign_inst.operand2_index;

                shiftNode();

                tmpNode->type = JMP;
                tmpNode->jmp_inst.target = loopCurrentNode;

                shiftNode();
                tmpNode->type = NOOP;
                loopCurrentNode->cjmp_inst.target = tmpNode;

                shiftNode();
                break;
            }
            case SWITCH: {
                int switchVar;
                nextToken = lexer.GetToken();
                while (nextToken.token_type != LBRACE) {
                    if (nextToken.token_type == ID) {
                        for (int i = 0; i < memLocations.size(); i++) {
                            if (nextToken.lexeme == memLocations[i]) {
                                switchVar = i;
                            }
                        }
                    }
                    nextToken = lexer.GetToken();
                }


                //InstructionNode *ifNode;
                bool first = true;
                vector<InstructionNode *> nodesNeedingNoop;
                while (nextToken.token_type != RBRACE) {
                    while (nextToken.token_type == CASE) {
                        //creating the if 

                        nextToken = lexer.GetToken();
                        tmpNode->type = CJMP;
                        tmpNode->cjmp_inst.condition_op = CONDITION_NOTEQUAL;
                        tmpNode->cjmp_inst.operand1_index = switchVar;
                        if (nextToken.token_type == NUM) {
                            int num = stoi(nextToken.lexeme);
                            int memIndex;
                            bool found = false;

                            for (int i = 0; i < memLocations.size(); i++) {
                                if (nextToken.lexeme == memLocations[i]) {
                                    memIndex = i;
                                    found = true;
                                }
                            }

                            if (!found) {
                                memIndex = next_available;
                                mem[next_available] = num;
                                memLocations.push_back(nextToken.lexeme);
                                next_available++;
                            }
                            tmpNode->cjmp_inst.operand2_index = memIndex;
                            InstructionNode *currentNode = tmpNode;

                            shiftNode();
                            shiftNode();

                            currentNode->cjmp_inst.target = tmpNode;

                            // Sets the return instruction to jump to the end

                            InstructionNode *buffNode;
                            buffNode = IfLoop();
                            tmpNode->type = JMP;
                            nodesNeedingNoop.push_back(tmpNode);
                            shiftNode();
                            currentNode->next = tmpNode;
                        }
                    }
                    while (nextToken.token_type == DEFAULT) {
                        InstructionNode *buffNode;
                        buffNode = IfLoop();
                        tmpNode->type = JMP;
                        nodesNeedingNoop.push_back(tmpNode);
                    }
                    nextToken = lexer.GetToken();
                }
                tmpNode->type = NOOP;

                for (int i = 0; i < nodesNeedingNoop.size(); i++) {
                    nodesNeedingNoop[i]->jmp_inst.target = tmpNode;
                }
                shiftNode();
                break;
            }
            case END_OF_FILE:
                break;
            case VAR:
                break;
            case CASE:
                break;
            case DEFAULT:
                break;
            case ARRAY:
                break;
            case PLUS:
                break;
            case MINUS:
                break;
            case DIV:
                break;
            case MULT:
                break;
            case EQUAL:
                break;
            case COLON:
                break;
            case COMMA:
                break;
            case SEMICOLON:
                break;
            case LBRAC:
                break;
            case RBRAC:
                break;
            case LPAREN:
                break;
            case RPAREN:
                break;
            case LBRACE:
                break;
            case RBRACE:
                break;
            case NOTEQUAL:
                break;
            case GREATER:
                break;
            case LESS:
                break;
            case NUM:
                break;
            case ERROR:
                break;
        }
        tmp = lexer.GetToken();
    }

    tmpNode->type = NOOP;
    tmpNode->next = NULL;

    while (tmp.token_type != END_OF_FILE) {
        if (tmp.token_type == NUM) {
            int tok = stoi(tmp.lexeme);
            inputs.push_back(tok);
        }
        tmp = lexer.GetToken();
    }

    return node;

}