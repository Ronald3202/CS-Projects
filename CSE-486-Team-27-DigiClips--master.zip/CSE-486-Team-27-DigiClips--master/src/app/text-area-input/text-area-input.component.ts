import { Component, Input, OnInit } from '@angular/core';
import { ControlContainer, FormGroupDirective, FormGroupName } from '@angular/forms';

@Component({
  selector: 'app-text-area-input',
  templateUrl: './text-area-input.component.html',
  styleUrls: ['./text-area-input.component.css'],
  viewProviders: [
    {
      provide: ControlContainer,
      useExisting: FormGroupDirective
    },
    {
      provide: ControlContainer,
      useExisting: FormGroupName
    }
]
})
export class TextAreaInputComponent implements OnInit {

  constructor() { }

  @Input() name;
  @Input() questionText;
  @Input() placeHolderText;
  @Input() isRequired = false;
  @Input() maxLength = 500;

  ngOnInit(): void {
  }

}
