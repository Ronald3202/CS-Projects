import { Component, OnDestroy, OnInit, ViewChild } from '@angular/core';
import { Router, NavigationEnd } from '@angular/router';
import { UntypedFormBuilder } from '@angular/forms';
import { Validators } from '@angular/forms';
import { SubmitFormService } from '../services/submit-form.service';
import bsCustomFileInput from 'bs-custom-file-input'
import { environment } from '../../environments/environment'

declare var jquery: any;
declare var $: any;


@Component({
  selector: 'app-samples',
  templateUrl: './samples.component.html',
  styleUrls: ['./samples.component.css']
})
export class SamplesComponent implements OnInit {
  protected samplesForm = this.fb.group({
    editedSegment: this.fb.group({
      email: [''],
      editedSegment: ['']
    })
  });

  protected disabled = false;
  protected loading = false;
  protected prod = environment.production;

  constructor(private fb: UntypedFormBuilder, private submitService: SubmitFormService) { }

  async onSubmit() {
    this.disabled = true;
    this.loading = true;
    this.samplesForm.disable();
    let res = await this.submitService.postSamplesService(this.samplesForm.value);
    if (res) {
      $("#confirmationModal").modal();
    } else {
      $("#failureModal").modal();
    }
    this.samplesForm.enable();
    this.loading = false;
    this.disabled = false;
  }


  ngOnInit(): void {
  }

}
