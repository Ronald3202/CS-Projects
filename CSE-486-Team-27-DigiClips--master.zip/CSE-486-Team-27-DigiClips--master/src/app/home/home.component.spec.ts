// External Libraries
import { ComponentFixture, TestBed, waitForAsync } from '@angular/core/testing';
import { RouterTestingModule } from '@angular/router/testing';

// Project Files
import { HomeComponent } from './home.component';
import { MarketsComponent } from '../markets/markets.component';

describe('HomeComponent', () => {
  let component: HomeComponent;
  let fixture: ComponentFixture<HomeComponent>;
  let compiled: any;

  beforeEach(waitForAsync(() => {
    TestBed.configureTestingModule({
      imports: [
        RouterTestingModule
      ],
      declarations: [
        HomeComponent,
        MarketsComponent
      ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(HomeComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
    compiled = fixture.debugElement.nativeElement;
  });

  it('should be created', () => {
    expect(component).toBeTruthy();
  });

  it('should display the carousel', waitForAsync(() => {
    expect(compiled.querySelector('#home-carousel').textContent)
      .toMatch('media intelligence services\\s+' +
               'We cover TV and radio in 210 United States' +
               '[\\s\\S]*' + // This matches anything.
               'no subscription required\\s+' +
               'request service');
  }));

  it('should display the first text block', waitForAsync(() => {
    expect(compiled.querySelectorAll('.text-block')[0].textContent)
      .toMatch('Research reports  with media values, audience numbers' +
               '[\\s\\S]*' + // This matches anything.
               'No per hit charges or required subscriptions');
  }));

  it('should display the first parallax image title', waitForAsync(() => {
    expect(compiled.querySelector('.bgimg-2').textContent)
      .toContain('personalized services');
  }));

  it('should display the second text block', waitForAsync(() => {
    expect(compiled.querySelectorAll('.text-block')[1].textContent)
      .toMatch('monitor mentions and subjects of interests from any media\\s+' +
               'television');
  }));

  it('should display the second parallax image title', waitForAsync(() => {
    expect(compiled.querySelector('.bgimg-3').textContent)
      .toContain('media verification');
  }));

  it('should display the third text block', waitForAsync(() => {
    expect(compiled.querySelectorAll('.text-block')[2].textContent)
      .toMatch('compliance and verification\\s+' +
               'Two words that strike fear');
  }));

  it('should display the third parallax image title', waitForAsync(() => {
    expect(compiled.querySelector('.bgimg-4').textContent)
      .toContain('ready to work with us?');
  }));

  it('should display the call-to-action buttons', waitForAsync(() => {
    expect(compiled.querySelector('.call-to-action-block').textContent)
      .toContain('request service');
    expect(compiled.querySelector('.call-to-action-block').textContent)
      .toContain('contact us');
  }));

  it('should head and close the markets modal properly', waitForAsync(() => {
    expect(compiled.querySelector('#MarketsModal').textContent)
      .toContain('we cover 210 usa markets');
    expect(compiled.querySelector('#MarketsModal').textContent)
      .toContain('close');
  }));
});
