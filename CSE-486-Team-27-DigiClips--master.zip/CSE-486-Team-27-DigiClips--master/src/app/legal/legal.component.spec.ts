// External Libraries
import { ComponentFixture, TestBed, waitForAsync } from '@angular/core/testing';
import { RouterTestingModule } from '@angular/router/testing';

// Project Files
import { LegalComponent } from './legal.component';

describe('LegalComponent', () => {
  let component: LegalComponent;
  let fixture: ComponentFixture<LegalComponent>;
  let compiled: any;

  beforeEach(waitForAsync(() => {
    TestBed.configureTestingModule({
      imports: [ RouterTestingModule ],
      declarations: [ LegalComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(LegalComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
    compiled = fixture.debugElement.nativeElement;
  });

  it('should be created', () => {
    expect(component).toBeTruthy();
  });

  it('should title page properly', waitForAsync(() => {
    expect(compiled.querySelectorAll('h4')[0].textContent)
      .toContain('DIGICLIPS IN CLOUD DVR');
    expect(compiled.querySelectorAll('h4')[1].textContent)
      .toContain('(Digital Video Audio Recorder)');
    expect(compiled.querySelector('h5').textContent)
      .toContain('Disclamer');
  }));

  it('should display the legal text', waitForAsync(() => {
    expect(compiled.querySelectorAll('p')[0].textContent)
      .toContain('DigiClips, Inc. employees, stockholders,');
    expect(compiled.querySelectorAll('p')[1].textContent)
      .toContain('Any and all materials supplied through DigiClips,');
    expect(compiled.querySelectorAll('p')[2].textContent)
      .toContain('It is fully understood DigiClips, Inc. is acting');
    expect(compiled.querySelectorAll('p')[3].textContent)
      .toContain('Any material can not be resold and redistributed ');
    expect(compiled.querySelectorAll('p')[4].textContent)
      .toContain('By approving the DigiClips disclaimer');
  }));
});
