// livechat.component.ts

import { AfterViewInit, Component, ElementRef, OnDestroy, OnInit, ViewChild } from '@angular/core';

@Component({
  selector: 'app-livechat',
  templateUrl: './livechat.component.html',
  styleUrls: ['./livechat.component.css']
})
export class LiveChatComponent implements OnInit, OnDestroy, AfterViewInit {
  title = 'livechat';

  @ViewChild('chatMessages') chatMessages: ElementRef;
  @ViewChild('userInput') userInput: ElementRef<HTMLInputElement>;
  @ViewChild('chatContainer') chatContainer: ElementRef;
  @ViewChild('chatIcon') chatIcon: ElementRef;
  @ViewChild('widgetChatHistory') widgetChatHistory: ElementRef;
  @ViewChild('wigetChatMessageWrapper') widgetChatMessageWrapper: ElementRef;
  @ViewChild('wigetChatMessageGroup') widgetChatMessageGroup: ElementRef;
  @ViewChild('buttonVisibleResponse') buttonVisibleResponse: ElementRef;
  @ViewChild('userInputContainer') userInputContainer: ElementRef;


  isChatOpen = false;
  ngOnInit() {
    // Initialization tasks not dependent on the view

  }
  ngOnDestroy() {
  }

  // This method should be called whenever a new message is added to the chat
  ngAfterViewInit() {
  }

  scrollToBottom() {
    this.widgetChatHistory.nativeElement.scrollTop = this.buttonVisibleResponse.nativeElement.scrollHeight;
  }

  toggleChatWindow() {
    this.isChatOpen = !this.isChatOpen;

  }


  questions = ['What we do ?', 'How we do it?', 'Chat with our Agent'];
  //selectedAnswers: string | null = null;
  //selectedQuestions: string | null = null;
  selectedQA: { question: string, answer: string }[] = [];

  showAnswer(question: string) {

    const answers = {
      'What we do ?': 'We offer real-time media monitoring and analysis to help clients stay informed and manage their public image effectively.',
      'How we do it?': 'We utilize advanced algorithms and human expertise to track and analyze media coverage in real-time, providing clients with actionable insights and comprehensive reports.',
      'Chat with our Agent': 'Connecting ...',
    };

    const answer = answers[question];
    this.selectedQA.push({ question, answer });
    this.scrollToBottom(); // FIXME: this won't work, not sure why
  }

  isSelected(question: string): boolean {
    return this.selectedQA.some(qa => qa.question === question);
  }

  getCurrentTime(): string {
    const now = new Date();
    const hours = now.getHours().toString().padStart(2, '0');
    const minutes = now.getMinutes().toString().padStart(2, '0');
    return `${hours}:${minutes}`;
  }

  handleInputKeyDown(event: KeyboardEvent) {
    if (event.key === "Enter") {
      this.sendMessage();
    }
  }

  messages: { content: string; isUser: boolean }[] = [];
  userMessage: string = '';
  sendMessage() {
    if (this.userMessage.trim() !== '') {
      this.messages.push({ content: this.userMessage, isUser: true });

      this.userMessage = '';

      // Simulate a response from the chatbot (you can replace this logic with your own chatbot API)
      setTimeout(() => {
        this.messages.push({ content: 'This is automatic response!', isUser: false });
      }, 500);
    }
  }
}