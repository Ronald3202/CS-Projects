// External Libraries
import { ComponentFixture, TestBed, waitForAsync } from '@angular/core/testing';
import { RouterTestingModule } from '@angular/router/testing';

// Project Files
import { ContactComponent } from './contact.component';

describe('ContactComponent', () => {
  let component: ContactComponent;
  let fixture: ComponentFixture<ContactComponent>;
  let compiled: any;

  beforeEach(waitForAsync(() => {
    TestBed.configureTestingModule({
      imports: [ RouterTestingModule ],
      declarations: [ ContactComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ContactComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
    compiled = fixture.debugElement.nativeElement;
  });

  it('should be created', () => {
    expect(component).toBeTruthy();
  });

  it('should display "contact us" the first parallax image', waitForAsync(() => {
    expect(compiled.querySelector('.bgimg-2').textContent)
      .toContain('contact us');
  }));

  it('should display the intro and first contacts', waitForAsync(() => {
    expect(compiled.querySelectorAll('.text-block')[0].textContent)
      .toMatch('We can take orders by phone or email' +
               '[\\s\\S]*' + // This matches anything.
               'paula shapiro\\s+' +
               'CEO & client relations manager');
  }));

  it('should display account department in the second parallax image', waitForAsync(() => {
    expect(compiled.querySelector('.bgimg-3').textContent)
      .toContain('accounting department');
  }));

  it('should display Bob\'s contact info', waitForAsync(() => {
    expect(compiled.querySelectorAll('.text-block')[1].textContent)
      .toMatch('bob shapiro\\s+chairman & acting CFO\\s+');
  }));

  it('should display "IT and software questions" in the third parallax image',
    waitForAsync(() => {
    expect(compiled.querySelector('.bgimg-4').textContent)
      .toContain('IT and software questions');
  }));

  it('should display Henry\'s contact info', waitForAsync(() => {
    expect(compiled.querySelectorAll('.text-block')[2].textContent)
      .toMatch('henry bremers\\s+senior software & IT engineer');
  }));
});
