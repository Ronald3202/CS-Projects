import { Component, OnDestroy, OnInit } from '@angular/core';
import { Router, NavigationEnd } from '@angular/router';

@Component({
  selector: 'app-services',
  templateUrl: './about.component.html',
  styleUrls: ['./about.component.css']
})

export class AboutComponent implements OnInit, OnDestroy {
  title = 'about';

  constructor(private router: Router) {}

  ngOnInit() {
    // This makes the page load at the top of the page
    this.router.events.subscribe((evt) => {
      if (!(evt instanceof NavigationEnd)) {
        return;
      }
      window.scrollTo(0, 0);
    });
    let navItem = document.getElementById('nav-about')
    navItem.classList.add('active');
  }

  ngOnDestroy() {
    let navItem = document.getElementById('nav-about')
    navItem.classList.remove('active');
  }
}
