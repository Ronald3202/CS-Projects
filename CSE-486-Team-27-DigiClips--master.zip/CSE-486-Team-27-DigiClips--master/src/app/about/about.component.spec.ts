// External Libraries
import { ComponentFixture, TestBed, waitForAsync } from '@angular/core/testing';
import { RouterTestingModule } from '@angular/router/testing';

// Project Files
import { AboutComponent } from './about.component';

describe('AboutComponent', () => {
  let component: AboutComponent;
  let fixture: ComponentFixture<AboutComponent>;
  let compiled: any;

  beforeEach(waitForAsync(() => {
    TestBed.configureTestingModule({
      imports: [
        RouterTestingModule
      ],
      declarations: [ AboutComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(AboutComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
    compiled = fixture.debugElement.nativeElement;
  });

  it('should be created', () => {
    expect(component).toBeTruthy();
  });

  it('should display "about us" the first parallax image', waitForAsync(() => {
    expect(compiled.querySelector('.bgimg-1').textContent)
      .toContain('about us');
  }));

  it('should display the general description of DigiClips', waitForAsync(() => {
    expect(compiled.querySelectorAll('.text-block')[0].textContent)
      .toContain('DigiClips, Inc. was established in 2003');
  }));

  it('should display Bob\'s name in the second parallax image', waitForAsync(() => {
    expect(compiled.querySelector('.bgimg-2').textContent)
      .toContain('robert shapiro');
  }));

  it('should display Bob\'s bio', waitForAsync(() => {
    expect(compiled.querySelectorAll('.text-block')[1].textContent)
      .toMatch('chairman & acting CFO\\s+' +
               'Mr. Shapiro Worked for Marathon Film Labs');
  }));

  it('should display Paula\'s name in the third parallax image', waitForAsync(() => {
    expect(compiled.querySelector('.bgimg-3').textContent)
      .toContain('paula shapiro');
  }));

  it('should display Paula\'s bio', waitForAsync(() => {
    expect(compiled.querySelectorAll('.text-block')[2].textContent)
      .toMatch('CEO & manager of client relations\\s+' +
               'Paula co-founded DigiClips along with her husband');
  }));

  it('should display Allan\'s name in the fourth parallax image', waitForAsync(() => {
    expect(compiled.querySelector('.bgimg-4').textContent)
      .toContain('allan dauber');
  }));

  it('should display Allan\'s bio', waitForAsync(() => {
    expect(compiled.querySelectorAll('.text-block')[3].textContent)
      .toMatch('senior account executive\\s+' +
               'Allan has been in the television monitoring business');
  }));

  it('should display Henry\'s name in the fifth parallax image', waitForAsync(() => {
    expect(compiled.querySelector('.bgimg-5').textContent)
      .toContain('henry bremers');
  }));

  it('should display Henry\'s bio', waitForAsync(() => {
    expect(compiled.querySelectorAll('.text-block')[4].textContent)
      .toMatch('senior software & IT engineer\\s+' +
               'Henry Bremers initially learned to write software in');
  }));
});
