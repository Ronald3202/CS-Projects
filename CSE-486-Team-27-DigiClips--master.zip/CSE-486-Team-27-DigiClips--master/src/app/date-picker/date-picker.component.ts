import { Component, Input, OnInit } from '@angular/core';
import { ControlContainer, FormGroupDirective, FormGroupName } from '@angular/forms';

@Component({
  selector: 'app-date-picker',
  templateUrl: './date-picker.component.html',
  styleUrls: ['./date-picker.component.css'],
    viewProviders: [
    {
      provide: ControlContainer,
      useExisting: FormGroupDirective
    },
    {
      provide: ControlContainer,
      useExisting: FormGroupName
    }
  ]
})
export class DatePickerComponent implements OnInit {

  constructor() { }

  @Input() name;
  @Input() questionText;
  @Input() isRequired = false;
  @Input() long = false;

  ngOnInit(): void {
  }

}
