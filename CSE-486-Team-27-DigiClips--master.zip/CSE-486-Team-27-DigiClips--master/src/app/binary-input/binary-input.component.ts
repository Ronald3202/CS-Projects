import { Component, Input, OnInit } from '@angular/core';
import { ControlContainer, FormGroupDirective, FormGroupName } from '@angular/forms';

@Component({
  selector: 'app-binary-input',
  templateUrl: './binary-input.component.html',
  styleUrls: ['./binary-input.component.css'],
  viewProviders: [
    {
        provide: ControlContainer,
        useExisting: FormGroupDirective
    }, 
    {
      provide: ControlContainer,
      useExisting: FormGroupName
    }
  ]
})

export class BinaryInputComponent implements OnInit {

  constructor() { }

  @Input() questionText;
  @Input() name;
  @Input() isRequired = false;

  ngOnInit(): void {
  }

}
