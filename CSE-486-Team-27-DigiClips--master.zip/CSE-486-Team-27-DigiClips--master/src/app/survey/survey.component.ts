import { Component, OnInit, OnDestroy } from '@angular/core';
import { UntypedFormBuilder, Validators } from '@angular/forms';
import { environment } from '../../environments/environment'
import { SubmitFormService } from '../services/submit-form.service';

declare var $: any;

@Component({
  selector: 'app-survey',
  templateUrl: './survey.component.html',
  styleUrls: ['./survey.component.css']
})
export class SurveyComponent implements OnInit, OnDestroy {

  constructor(private fb: UntypedFormBuilder, private submitService: SubmitFormService) { }

  protected surveyForm = this.fb.group({
    questions: this.fb.group({
      competitors: [''],
      competitorsOther: [''],
      likeComments: [''],
      dislikeComments: [''],
      missedData: [''],
      scrapedData: [''],
      mediaList: [''],
      monitoredMedia: [''],
      subscriptionPreference: [''],
      subscriptionRenewal: [''],
      perNeed: [''],
      needAnalytics: [''],
      improveComments: [''],
      needMediaReport: [''],
      needBroadcastReport: [''],
      needOnlineReport: [''],
      needProfessionallyEditedSegment: [''],
      macFormat: [''],
      pcFormat: [''],
      hdResolution: [''],
      standardResolution: [''],
      needTranscripts: [''],
      needContacts: [''],
      needArchived: [''],

      //omitMedia: [''],
      //needMediaList: [''],
      //preferYearSub: [''],
      //hasAutoRenewal: [''],
      //mediaType: [''],
      //displayType: [''],
      //tvRes: [''],
    }),
    termsAndConditions: this.fb.group({
      termscond: ['', Validators.requiredTrue]
    })
  });

  protected disabled = false;
  protected loading = false;
  protected prod = environment.production;

  ngOnInit(): void {
    window.scrollTo(0, 0);

    let navItem = document.getElementById('nav-survey')
    navItem.classList.add('active');
  }

  ngOnDestroy() {
    let navItem = document.getElementById('nav-survey')
    navItem.classList.remove('active');
  }

  onCheckboxData(data: { [key: string]: boolean }) {
    console.log('Received checkbox data:', data);
  }


  async onSubmit() {
    this.disabled = true;
    this.loading = true;
    this.surveyForm.disable();
    let res = await this.submitService.postSurvey(this.surveyForm.value);
    if (res) {
      $("#confirmationModal").modal();
    } else {
      $("#failureModal").modal();
    }
    this.surveyForm.enable();
    this.loading = false;
    this.disabled = false;
  }

}
