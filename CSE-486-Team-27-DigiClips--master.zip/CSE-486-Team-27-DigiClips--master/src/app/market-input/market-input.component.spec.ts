import { ComponentFixture, TestBed } from '@angular/core/testing';

import { MarketInputComponent } from './market-input.component';

describe('MarketInputComponent', () => {
  let component: MarketInputComponent;
  let fixture: ComponentFixture<MarketInputComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ MarketInputComponent ]
    })
    .compileComponents();

    fixture = TestBed.createComponent(MarketInputComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
