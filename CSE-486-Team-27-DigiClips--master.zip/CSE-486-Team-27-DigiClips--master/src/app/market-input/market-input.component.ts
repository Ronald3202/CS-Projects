import { Component, Input, OnInit } from '@angular/core';
import { ControlContainer, FormGroupDirective, FormGroupName } from '@angular/forms';
import { GetMarketsService } from '../services/get-markets.service';

@Component({
  selector: 'app-market-input',
  templateUrl: './market-input.component.html',
  styleUrls: ['./market-input.component.css'], 
  viewProviders: [
    {
      provide: ControlContainer,
      useExisting: FormGroupDirective
    }, 
    {
      provide: ControlContainer,
      useExisting: FormGroupName
    }
  ]
})
export class MarketInputComponent implements OnInit {
  protected markets = this.getMarketsService.getRankOrder();
  @Input() name;
  
  constructor(private getMarketsService: GetMarketsService) { }

  ngOnInit(): void {

  }
}
