import { Component, OnDestroy, OnInit } from '@angular/core';
import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';
import { StaticBackgroundComponent } from '../static-background/static-background.component';

@Component({
  selector: 'app-ratesheet',
  templateUrl: './ratesheet.component.html',
  styleUrls: ['./ratesheet.component.css']
})

export class RatesheetComponent implements OnInit, OnDestroy {

  constructor() { }

  ngOnInit(): void {
    window.scrollTo(0, 0);
  
    let navItem = document.getElementById('nav-ratesheet')
    navItem.classList.add('active');
  }

  ngOnDestroy() {
    let navItem = document.getElementById('nav-ratesheet')
    navItem.classList.remove('active');
  }

}
