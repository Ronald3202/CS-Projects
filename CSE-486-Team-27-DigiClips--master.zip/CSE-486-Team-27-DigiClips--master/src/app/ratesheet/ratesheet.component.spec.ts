import { ComponentFixture, TestBed } from '@angular/core/testing';

import { RatesheetComponent } from './ratesheet.component';

describe('RatesheetComponent', () => {
  let component: RatesheetComponent;
  let fixture: ComponentFixture<RatesheetComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ RatesheetComponent ]
    })
    .compileComponents();

    fixture = TestBed.createComponent(RatesheetComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
