// External Libraries
import { provideHttpClient, withInterceptorsFromDi } from '@angular/common/http';
import { NgModule } from '@angular/core';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { BrowserModule } from '@angular/platform-browser';

// Project Components
import { AboutComponent } from './about/about.component';
import { AppComponent } from './app.component';
import { ContactComponent } from './contact/contact.component';
import { HomeComponent } from './home/home.component';
import { LegalComponent } from './legal/legal.component';
import { MarketsComponent } from './markets/markets.component';
import { RequestServiceComponent } from './requestservice/requestservice.component';

// Other Project Files
import { AppRoutingModule } from './app-routing.module';
import { BinaryInputComponent } from './binary-input/binary-input.component';
import { CheckboxInputComponent } from './checkbox-input/checkbox-input.component';
import { DatePickerComponent } from './date-picker/date-picker.component';
import { DownloadComponent } from './download/download.component';
import { EmailSignupComponent } from './email-signup/email-signup.component';
import { RecommendationsComponent } from './lettersofrecommendations/lettersofrecommendations.component';
import { LiveChatComponent } from './livechat/livechat.component';
import { MarketInputComponent } from './market-input/market-input.component';
import { RatesheetComponent } from './ratesheet/ratesheet.component';
import { SamplesComponent } from './samples/samples.component';
import { SelectInputComponent } from './select-input/select-input.component';
import { SubmitFormService } from './services/submit-form.service';
import { SocialMediaComponent } from './social-media/social-media.component';
import { StaticBackgroundComponent } from './static-background/static-background.component';
import { SurveyComponent } from './survey/survey.component';
import { TermsConditionsComponent } from './terms-conditions/terms-conditions.component';
import { TextAreaInputComponent } from './text-area-input/text-area-input.component';
import { TextInputComponent } from './text-input/text-input.component';

@NgModule({ declarations: [
        AppComponent,
        HomeComponent,
        AboutComponent,
        ContactComponent,
        LegalComponent,
        RequestServiceComponent,
        MarketsComponent,
        SurveyComponent,
        RatesheetComponent,
        SocialMediaComponent,
        StaticBackgroundComponent,
        BinaryInputComponent,
        SelectInputComponent,
        EmailSignupComponent,
        TextAreaInputComponent,
        TermsConditionsComponent,
        TextInputComponent,
        MarketInputComponent,
        CheckboxInputComponent,
        RecommendationsComponent,
        DownloadComponent,
        DatePickerComponent,
        SamplesComponent,
        LiveChatComponent,
    ],
    bootstrap: [AppComponent], imports: [BrowserModule,
        ReactiveFormsModule,
        AppRoutingModule,
        FormsModule,
        AppRoutingModule], providers: [SubmitFormService, provideHttpClient(withInterceptorsFromDi())] })
export class AppModule { }
