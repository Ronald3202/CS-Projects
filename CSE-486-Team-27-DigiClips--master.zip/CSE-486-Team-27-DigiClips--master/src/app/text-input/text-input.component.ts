import { Component, Input, OnInit } from '@angular/core';
import { ControlContainer, FormGroupDirective, FormGroupName } from '@angular/forms';

@Component({
  selector: 'app-text-input',
  templateUrl: './text-input.component.html',
  styleUrls: ['./text-input.component.css'],
  viewProviders: [
    {
      provide: ControlContainer,
      useExisting: FormGroupDirective
    }, 
    {
      provide: ControlContainer,
      useExisting: FormGroupName
    }
  ]
})
export class TextInputComponent implements OnInit {

  constructor() { }

  
  @Input() name;
  @Input() questionText;
  @Input() placeHolderText = false;
  @Input() isRequired = false;
  @Input() maxLength = 50;

  @Input() name2 = "";
  @Input() questionText2;
  @Input() placeHolderText2 = "";
  @Input() isRequired2 = false;
  @Input() maxLength2 = 50;

  ngOnInit(): void {
    
  }

}
