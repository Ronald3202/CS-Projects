import { ComponentFixture, TestBed } from '@angular/core/testing';

import { StaticBackgroundComponent } from './static-background.component';

describe('StaticBackgroundComponent', () => {
  let component: StaticBackgroundComponent;
  let fixture: ComponentFixture<StaticBackgroundComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ StaticBackgroundComponent ]
    })
    .compileComponents();

    fixture = TestBed.createComponent(StaticBackgroundComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
