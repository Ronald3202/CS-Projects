import { Component, Input, OnInit } from '@angular/core';

@Component({
  selector: 'app-static-background',
  templateUrl: './static-background.component.html',
  styleUrls: ['./static-background.component.css']
})
export class StaticBackgroundComponent implements OnInit {

  constructor() { }

  @Input() imageUrl;

  ngOnInit(): void {
  }

}
