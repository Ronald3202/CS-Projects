// External Libraries
import { ComponentFixture, TestBed, waitForAsync } from '@angular/core/testing';
import { FormsModule } from '@angular/forms';
import { RouterTestingModule } from '@angular/router/testing';

// Project Files
import { RequestServiceComponent } from './requestservice.component';
import { EmailService } from '../services/email.service';
import { MockEmailService } from '../services/email.service.mock';
import { RequestForm } from '../classes/request-form';

describe('RequestServiceComponent', () => {
  let component: RequestServiceComponent;
  let fixture: ComponentFixture<RequestServiceComponent>;
  let compiled: any;

  beforeEach(waitForAsync(() => {
    TestBed.configureTestingModule({
      imports: [
        FormsModule,
        RouterTestingModule
      ],
      declarations: [
        RequestServiceComponent
      ],
      providers: [
        { provide: EmailService, useValue: MockEmailService }
      ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(RequestServiceComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
    compiled = fixture.debugElement.nativeElement;
  });

  it('should be created', () => {
    expect(component).toBeTruthy();
  });

  it('should display the form', waitForAsync(() => {
    expect(compiled.querySelector('.form-container').textContent)
      .toMatch('service request form\\s+' +
               'Receive your clip within 24 hours of submitting the form below. We will work within your budget.\\s+' +
               'contact us for help\\s+' +
               'First Name' +
               '[\\s\\S]*' + // This matches anything.
               'Enter in any comments and instructions' +
               '[\\s\\S]*' +
               'Terms and Conditions' +
               '[\\s\\S]*' +
               'submit');
  }));

  it('validMediaCheckBoxForRR should return true if orderType is not ' +
      '"Research Report"', () => {
    component.requestForm.orderType = 'Not research!';
    expect(component.validMediaCheckBoxForRR()).toBe(true);
  });

  it('validMediaCheckBoxForRR should return false if the orderType is ' +
      '"Research Report" and no media reports are true', () => {
    component.requestForm.orderType = 'Research Report';
    component.requestForm.mediaReportBroadcast = false;
    component.requestForm.mediaReportNewspaper = false;
    component.requestForm.mediaReportMagazines = false;
    component.requestForm.mediaReportSocialMedia = false;
    component.requestForm.mediaReportBlogs = false;
    component.requestForm.mediaReportWeb = false;
    expect(component.validMediaCheckBoxForRR()).toBe(false);
  });

  // TODO: test ngOnInit() appropriately
  // TODO: test submit() appropriately

  it('validMediaCheckBoxForRR should return false if the orderType is ' +
      '"Research Report" and at least one media report is true', () => {
    component.requestForm.orderType = 'Research Report';
    component.requestForm.mediaReportBroadcast = false;
    component.requestForm.mediaReportNewspaper = false;
    component.requestForm.mediaReportMagazines = true;
    component.requestForm.mediaReportSocialMedia = false;
    component.requestForm.mediaReportBlogs = false;
    component.requestForm.mediaReportWeb = false;
    expect(component.validMediaCheckBoxForRR()).toBe(true);
  });

  it('resetForm should set a new requestForm, set failedRequest to false, and' +
     'call form.reset()', () => {
    spyOn(component.form, 'reset').and.callThrough();
    component.resetForm();
    expect(component.requestForm).toEqual(new RequestForm());
    expect(component.failedRequest).toBe(false);
    expect(component.form.reset).toHaveBeenCalledTimes(1);
  });
});
