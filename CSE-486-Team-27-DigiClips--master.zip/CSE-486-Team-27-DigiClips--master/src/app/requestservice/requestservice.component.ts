// External Libraries
import { Component, OnDestroy, OnInit, ViewChild } from '@angular/core';
import { Router, NavigationEnd } from '@angular/router';
import { UntypedFormBuilder } from '@angular/forms';
import { Validators } from '@angular/forms';
import { SubmitFormService } from '../services/submit-form.service';
import bsCustomFileInput from 'bs-custom-file-input'
import { environment } from '../../environments/environment'

declare var jquery: any;
declare var $: any;

@Component({
  selector: 'app-requestservice',
  templateUrl: './requestservice.component.html',
  styleUrls: ['./requestservice.component.css'],
})

export class RequestServiceComponent implements OnInit, OnDestroy {
  protected requestForm = this.fb.group({
    profile: this.fb.group({
      organization: ['', Validators.required],
      firstName: ['', Validators.required],
      lastName: ['', Validators.required],
      address: this.fb.group({
        street: ['', Validators.required],
        city: ['', Validators.required],
        state: ['', Validators.required],
        country: ['', Validators.required],
        zip: ['', Validators.required]
      }),
      phone: ['', Validators.required],
      email: ['', Validators.compose([Validators.required, Validators.pattern("\\S+@\\S+")])],
    }),
    professionallyEditedSegment: this.fb.group ({
      professionallyEditedCheckbox: this.fb.group ({
        television: [''],
        radio: [''],
        usaStatesMarkets: [''],
        international: ['']
      })
    }),
    televisionFormat: this.fb.group({

    }),
    resolution: this.fb.group({

    }),
    reports: this.fb.group({
      mediaReports: [''],
      reportStart: [''],
      reportEnd: [''],
      reportsCheckbox: [''],
      reportMarkets: ['']
    }),
    addOns: this.fb.group({
      keywords: ['', Validators.required],
      transcripts: [''],
      comments: [''],
    }),
    termsAndConditions: this.fb.group({
      termscond: ['', Validators.requiredTrue]
    })
  });

  protected disabled = false;
  protected loading = false;
  protected pressRelease = null;
  protected prod = environment.production;

  constructor(private fb: UntypedFormBuilder, private submitService: SubmitFormService) { }

  async onSubmit() {
    this.disabled = true;
    this.loading = true;
    this.requestForm.disable();
    let res = await this.submitService.postRequestService(this.requestForm.value, this.pressRelease);
    if (res) {
      $("#confirmationModal").modal();
    } else {
      $("#failureModal").modal();
    }
    this.requestForm.enable();
    this.loading = false;
    this.disabled = false;
  }

  handleFileInput(files: FileList) {
    this.pressRelease = files.item(0);
  }

  ngOnInit() {
      bsCustomFileInput.init();
      window.scrollTo(0, 0);
      let navItem = document.getElementById('nav-requestservice')
      navItem.classList.add('active');
    }

    ngOnDestroy() {
      let navItem = document.getElementById('nav-requestservice')
      navItem.classList.remove('active');
    }
}
