import { Component, Input, OnInit } from '@angular/core';
import { UntypedFormBuilder, Validators } from '@angular/forms';
import { SubmitFormService } from '../services/submit-form.service';

@Component({
  selector: 'app-email-signup',
  templateUrl: './email-signup.component.html',
  styleUrls: ['./email-signup.component.css']
})
export class EmailSignupComponent implements OnInit {

  constructor(private fb: UntypedFormBuilder, private submitService: SubmitFormService) { }

  protected emailForm = this.fb.group({
    email: ['', Validators.compose([Validators.required, Validators.pattern("\\S+@\\S+")])]
  });

  protected finished = false;

  @Input() showHeader = true;

  ngOnInit(): void {
  }

  async onSubmit() {
    this.emailForm.disable();
    let res = await this.submitService.postEmail(this.emailForm.value);
    if (res) {
      this.finished = true;
    } else {
      this.emailForm.enable();
    }
    this.emailForm.reset();
  }

}
