import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-social-media',
  templateUrl: './social-media.component.html',
  styleUrls: ['./social-media.component.css']
})
export class SocialMediaComponent implements OnInit {
  protected facebookLink = "https://www.facebook.com/digiclipsinc";
  protected twitterLink = "https://twitter.com/digiclips";
  protected instagramLink = "https://www.instagram.com/digi_clips/";
  protected linkedinLink = "https://www.linkedin.com/in/bob-shapiro-3bb2805/"
  constructor() { }

  ngOnInit(): void {
  }

}
