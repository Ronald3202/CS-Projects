import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';


@Injectable({
  providedIn: 'root'
})

export class SubmitFormService {
  private apiURL = location.protocol + "//localhost:8080";
  private samplesServiceURL = this.apiURL + "/submit/samples"
  private requestServiceURL = this.apiURL + "/submit/requestservice";
  private surveyURL = this.apiURL + "/submit/survey";
  private emailURL = this.apiURL + "/submit/email";

  constructor(private http: HttpClient) { }

  postSamplesService(form) {
    return new Promise((resolve, reject) => {
      let xhr = new XMLHttpRequest();

      let formData = new FormData();
      formData.append("formInputs", JSON.stringify(form));

      xhr.open("POST", this.samplesServiceURL, true);
      xhr.setRequestHeader('Access-Control-Allow-Origin', '*');
      xhr.onreadystatechange = function () {
        if (xhr.readyState == 4) {
          if (xhr.status >= 200 && this.status < 300) {
            resolve(xhr.response);
          }
          else {
            reject({
              status: this.status,
              statusText: xhr.statusText
            })
          }

        }
      };

      xhr.send(formData);
    });
  }

  postRequestService(form, pressRelease) {
    //https://stackoverflow.com/questions/51678476/sending-json-data-to-server-with-expressjs
    //https://stackoverflow.com/questions/48969495/in-javascript-how-do-i-should-i-use-async-await-with-xmlhttprequest
    return new Promise((resolve, reject) => {
      let xhr = new XMLHttpRequest();

      let formData = new FormData();
      formData.append("formInputs", JSON.stringify(form));
      formData.append("pressRelease", pressRelease);

      xhr.open("POST", this.requestServiceURL, true);
      xhr.setRequestHeader('Access-Control-Allow-Origin', '*');
      xhr.onreadystatechange = function () {
        if (xhr.readyState == 4) {
          if (xhr.status >= 200 && this.status < 300) {
            resolve(xhr.response);
          }
          else {
            reject({
              status: this.status,
              statusText: xhr.statusText
            })
          }

        }
      };

      xhr.send(formData);
    });
  }

  async postSurvey(form) {
    //try {
    //let res = await this.http.post<any>(this.surveyURL, form).toPromise();
    //return res;
    //} catch (e) {
    //console.log(e);
    //return false;
    //}
    return new Promise((resolve, reject) => {
      let formData = new FormData();
      formData.append("formInputs", JSON.stringify(form));

      let xhr = new XMLHttpRequest();
      xhr.open("POST", this.surveyURL, true);
      xhr.setRequestHeader('Access-Control-Allow-Origin', '*');
      xhr.onreadystatechange = function () {
        if (xhr.readyState == 4) {
          if (xhr.status >= 200 && this.status < 300) {
            resolve(true);
          }
          else {
            reject({
              status: this.status,
              statusText: xhr.statusText
            })
          }
        }
      };

      xhr.send(formData);
    });
  }

  async format(form, questionsMap) {
    return new Promise((resolve, reject) => {
      let formattedString = "";
      let questionCount = 1;
      questionsMap.forEach((questionText, name) => {
        if (form.questions[name]) {
          formattedString += `${questionCount}. ${questionText} \n\t- ${form.questions[name]}\n`;
          questionCount++;
        }
      });

      formattedString += `Terms and Conditions Accepted: ${form.termsAndConditions.termscond ? "Yes" : "No"
        }`;

      console.log(formattedString);
      resolve(formattedString);
    });
  }

  async postEmail(form) {
    //try {
    //let res = await this.http.post<any>(this.emailURL, form).toPromise();
    //return res;
    //} catch (e) {
    //console.log(e);
    //return false;
    //}
    return new Promise((resolve, reject) => {
      let formData = new FormData();
      formData.append("formInputs", JSON.stringify(form));

      let xhr = new XMLHttpRequest();
      xhr.open("POST", this.emailURL, true);
      xhr.setRequestHeader('Access-Control-Allow-Origin', '*');
      xhr.onreadystatechange = function () {
        if (xhr.readyState == 4) {
          if (xhr.status >= 200 && this.status < 300) {
            resolve(true);
          }
          else {
            reject({
              status: this.status,
              statusText: xhr.statusText
            })
          }
        }
      };
      xhr.send(formData);
    })
  }
}

