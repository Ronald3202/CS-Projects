import { TestBed } from '@angular/core/testing';

import { GetMarketsService } from './get-markets.service';

describe('GetMarketsService', () => {
  let service: GetMarketsService;

  beforeEach(() => {
    TestBed.configureTestingModule({});
    service = TestBed.inject(GetMarketsService);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });
});
