// External Libraries
import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';

// Project Components
import { AboutComponent } from './about/about.component';
import { ContactComponent } from './contact/contact.component';
import { DownloadComponent } from './download/download.component';
import { HomeComponent } from './home/home.component';
import { LegalComponent } from './legal/legal.component';
import { RecommendationsComponent } from './lettersofrecommendations/lettersofrecommendations.component';
import { LiveChatComponent } from './livechat/livechat.component';
import { RatesheetComponent } from './ratesheet/ratesheet.component';
import { RequestServiceComponent } from './requestservice/requestservice.component';
import { SamplesComponent } from './samples/samples.component';
import { SurveyComponent } from './survey/survey.component';

const routes: Routes = [
  {
    path: 'home',
    component: HomeComponent,
    children: []
  },
  {
    path: 'about',
    component: AboutComponent,
    children: []
  },
  {
    path: 'samples',
    component: SamplesComponent,
    children: []
  },
  {
    path: 'contact',
    component: ContactComponent,
    children: []
  },
  {
    path: 'legal',
    component: LegalComponent,
    children: []
  },
  {
    path: 'requestservice',
    component: RequestServiceComponent,
    children: []
  },
  {
    path: 'ratesheet',
    component: RatesheetComponent,
    children: []
  },
  {
    path: 'survey',
    component: SurveyComponent,
    children: []
  },
  {
    path: 'lettersofrecommendations',
    component: RecommendationsComponent,
    children: []
  },
  {
    path: 'download',
    component: DownloadComponent,
    children: []
  },
  {
    path: 'livechat',
    component: LiveChatComponent,
    children: []
  },
  { path: '', redirectTo: 'home', pathMatch: 'full' },
];

@NgModule({
  imports: [RouterModule.forRoot(routes, { useHash: true })],
  exports: [RouterModule]
})
export class AppRoutingModule { }
