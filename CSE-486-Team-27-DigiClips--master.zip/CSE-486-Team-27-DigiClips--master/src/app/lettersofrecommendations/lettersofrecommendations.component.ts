import { Component, OnInit } from '@angular/core';
import { NavigationEnd, Router } from '@angular/router';

@Component({
  selector: 'app-lettersofrecommendations',
  templateUrl: './lettersofrecommendations.component.html',
  styleUrls: ['./lettersofrecommendations.component.css']
})
export class RecommendationsComponent implements OnInit {
  title = 'lettersofrecommendations'

  constructor(private router: Router) { }

  ngOnInit() {
    // This makes the page load at the top of the page
    this.router.events.subscribe((evt) => {
      if (!(evt instanceof NavigationEnd)) {
        return;
      }
      window.scrollTo(0, 0);
    });
    let navItem = document.getElementById('nav-lettersofrecommendations')
    navItem.classList.add('active');
  }

  ngOnDestroy() {
    let navItem = document.getElementById('nav-lettersofrecommendations')
    navItem.classList.remove('active');
  }
}
