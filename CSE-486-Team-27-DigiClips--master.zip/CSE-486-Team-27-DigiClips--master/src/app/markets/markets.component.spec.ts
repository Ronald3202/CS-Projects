// External Libraries
import { ComponentFixture, TestBed, waitForAsync } from '@angular/core/testing';
import { RouterTestingModule } from '@angular/router/testing';

// Project Files
import { MarketsComponent } from './markets.component';

describe('MarketsComponent', () => {
  let component: MarketsComponent;
  let fixture: ComponentFixture<MarketsComponent>;
  let compiled: any;

  beforeEach(waitForAsync(() => {
    TestBed.configureTestingModule({
      imports: [ RouterTestingModule ],
      declarations: [ MarketsComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(MarketsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
    compiled = fixture.debugElement.nativeElement;
  });

  it('should be created', () => {
    expect(component).toBeTruthy();
  });

  it('should be initially list markets by DMA', waitForAsync(() => {
    expect(compiled.querySelector('.markets-container').textContent)
      .toMatch('listed by DMA\\s+' +
               'list alphabetically instead\\s+' +
               'New York\\s+' +
               'Los Angeles\\s+' +
               'Chicago');
  }));

  it('should list U.S. territories', waitForAsync(() => {
    expect(compiled.querySelector('h4').textContent)
      .toContain('us territories, commonwealths and insular areas');
    expect(compiled.querySelector('.markets-container').textContent)
      .toContain('United States Virgin Islands');
    expect(compiled.querySelector('.markets-container').textContent)
      .toContain('Puerto Rico');
  }));

  it('listByDMA should set listMode to "DMA"', () => {
    component.listByDMA();
    expect(component.listMode).toEqual('DMA');
  });

  it('listAlphabetically should set listMode to "Alphabetically"', () => {
    component.listAlphabetically();
    expect(component.listMode).toEqual('Alphabetically');
  });
});
