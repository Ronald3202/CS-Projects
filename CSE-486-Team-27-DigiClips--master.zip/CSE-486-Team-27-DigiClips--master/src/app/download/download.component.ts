import { Component, OnInit } from '@angular/core';
import { Router, NavigationEnd } from '@angular/router';

@Component({
  selector: 'app-download',
  templateUrl: './download.component.html',
  styleUrls: ['./download.component.css']
})
export class DownloadComponent implements OnInit {
  private deferredPrompt: any;
  title = 'download'

  constructor(private router: Router) { }

  ngOnInit() {
    // This makes the page load at the top of the page
    this.router.events.subscribe((evt) => {
      if (!(evt instanceof NavigationEnd)) {
        return;
      }
      window.scrollTo(0, 0);
    });
    let navItem = document.getElementById('nav-download')
    navItem.classList.add('active');

    window.addEventListener('beforeinstallprompt', (event:Event) => {
      event.preventDefault();
      this.deferredPrompt = event;
    })
  }

  ngOnDestroy() {
    let navItem = document.getElementById('nav-download')
    navItem.classList.remove('active');
  }
  installApp() {
    if (this.deferredPrompt)
      this.deferredPrompt.prompt();
  }
}

