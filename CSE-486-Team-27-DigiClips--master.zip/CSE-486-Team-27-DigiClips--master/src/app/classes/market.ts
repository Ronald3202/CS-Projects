export class Market {
  constructor(
    public name: string, public rank: number) { }
}
