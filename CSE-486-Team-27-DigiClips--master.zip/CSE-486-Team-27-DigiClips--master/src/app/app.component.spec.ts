// External Libraries
import { ComponentFixture, TestBed, waitForAsync } from '@angular/core/testing';
import { AppComponent } from './app.component';
import { RouterTestingModule } from '@angular/router/testing';

describe('AppComponent', () => {
  let app: AppComponent;
  let fixture: ComponentFixture<AppComponent>;
  let compiled: any;

  beforeEach(waitForAsync(() => {
    TestBed.configureTestingModule({
      imports: [
        RouterTestingModule
      ],
      declarations: [
        AppComponent
      ],
    }).compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(AppComponent);
    app = fixture.debugElement.componentInstance;
    fixture.detectChanges();
    compiled = fixture.debugElement.nativeElement;
  });

  it('should create the app', waitForAsync(() => {
    expect(app).toBeTruthy();
  }));

  it(`should have as title 'app'`, waitForAsync(() => {
    expect(app.title).toEqual('app');
  }));

  it('should have "DigiClips" in the navbar', waitForAsync(() => {
    expect(compiled.querySelector('.navbar-brand').textContent)
      .toContain('DigiClips');
  }));

  it('should have links in the navbar', waitForAsync(() => {
    expect(compiled.querySelectorAll('.nav-link')[0].textContent)
      .toContain('Request Service');
    expect(compiled.querySelectorAll('.nav-link')[1].textContent)
      .toContain('Contact Us');
    expect(compiled.querySelectorAll('.nav-link')[2].textContent)
      .toContain('About Us');
  }));

  it('should have links in the footer', waitForAsync(() => {
    expect(compiled.querySelectorAll('.foot-link')[0].textContent)
      .toContain('legal');
    expect(compiled.querySelectorAll('.foot-link')[1].textContent)
      .toContain('contact us');
  }));

  it('should have the copyright in the footer', waitForAsync(() => {
    expect(compiled.querySelector('.footer').textContent)
      .toContain('DigiClips® is a U.S. registered service mark of the Robert');
  }));
});
