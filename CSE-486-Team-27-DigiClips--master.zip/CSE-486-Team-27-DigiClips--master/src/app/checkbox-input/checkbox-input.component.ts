import { Component, Input, OnInit } from '@angular/core';
import { ControlContainer, FormGroupDirective, FormGroupName } from '@angular/forms';


@Component({
  selector: 'app-checkbox-input',
  templateUrl: './checkbox-input.component.html',
  styleUrls: ['./checkbox-input.component.css'],
  viewProviders: [
    {
      provide: ControlContainer,
      useExisting: FormGroupDirective
    },
    {
      provide: ControlContainer,
      useExisting: FormGroupName
    }
  ]

})
export class CheckboxInputComponent implements OnInit {

  @Input() name;
  @Input() questionText;
  @Input() options = ['1','2','3'];
  @Input() isRequired = false;
  @Input() long = false;

  checkboxStates: { [key: string]: boolean } = {};

  constructor() {
  }

  ngOnInit(): void {
  }

}
