# DcWeb

This project was generated with [Angular CLI](https://github.com/angular/angular-cli) version 18.2.10

## Dependancies 

Install dependencies using `npm install` in both the project root and `server` directories.

## Development server

Run `ng serve` for a dev server. Navigate to `http://localhost:4200/`. The app will automatically reload if you change any of the source files. Add the flag `–configuration production` to run a production version.

## Code scaffolding

Run `ng generate component component-name` to generate a new component. You can also use `ng generate directive|pipe|service|class|guard|interface|enum|module`.

## Build

Run `ng build` to build the project. The build artifacts will be stored in the `server/dist` directory. Add the flag `–configuration production` to run a production build.

## Run Server

Run `node server.js` from the server directory. Use the flag `--production` when running for production. Server runs on port 80. All the necessary files for the server are in the server directory.

## Further help

To get more help on the Angular CLI use `ng help` or go check out the [Angular CLI README](https://github.com/angular/angular-cli/blob/master/README.md).

## Pages

The directories about, contact, home, legal, ratesheet, requestservice, survey contain the code for the corresponding pages. These components are inserted into the app component with the router outlet. The routing paths are defined in app-routing.module.ts. The app component also contains the navigation bar and footer bar which stay the same between pages.

Currently, the current page is highlighted on the navigation bar by having that page manually add an 'active' tag on load. It is removed when leaving the page. There is definitely a better way to do this. 


## Livechat
UI on the frond-end of Info page is pretty much complete. Need work on the back end as well as UI for an agent (could be on Administration page) 

## Widgets 

social-media: The links to social media accounts in the footer.

static-background: The single background used in requestservice, ratesheet, and survey.

email-signup: The input for signing up for emails on the home page and the contact page. It takes an boolean input `showHeader` to have the "subscribe to our email list" appear with the input. It has a variable `finished` to disable the input after an email is successful submitted

market: The button and popup on the home page that displays markets covered.

## Inputs

These components are used to create the request service and survey forms. 

binary-input: The input for yes/no questions on the survey.

market-input: The input for selecting one or multiple markets on the request service page. The markets come the get-markets-service. It would be nice to have a button to toggle between sorting by rank or alphabet but it might erase previous selections.

select-input: The drop down input.

text-area-input: The input for typing long text comments.

text-input: The single line input for shorter text comments. 

These components can take a few inputs (@Input). They don't all have the ones listed below.

name: The formControlName to be used in the reactive form object.

questionText: The displayed text for the user to answer.

placeHolderText: The text to show before the user inputs something.

isRequired: Adds an asterick next to the input to indicate it must be answered.

maxLength: The limit on how many characters can be typed into the input.

options: An array of the different choices for the select-input.

long: Used to adjust the size of select-input between the survey and requestservice pages.

The text-input also has name2, questionText2, etc. in the case where we want to two text inputs side by side like with first and last name on the request service page.

The inputs also have the ViewProviders called FormGroupDirective and FormGroupName. These let the reactive form in the page link up with the inputs in the separate components. Because we inject FormGroupName, all the inputs need to be nested inside a form group. There is probably a better way to do this.

## Services

get-markets: Provides function to get markets sorted by rank or alphabet. Should probably separate the market data into another file and make the market component use this service.

submit-form: Takes in data in sends it to the server. Used for email, survery, and request service submission with a different function for each. It sends the request to the same domain the website is on. All the functions return true on success and false otherwise. 

The request service form sends both the form data and the uploaded file. These are appended to a formData object. This allows us to send the request as a multi-part type which is needed to send the file.

## Server Workings

The file .env contains usernames and passwords. The password is an app password that you get from GMail security settings, not the actual account password. It lets us use the email address to send messages over "Simple Mail Transfer Protocol". The email receipt changes based on whether the `--production` flag was used when starting the server.

The library multer is used to extract the uploaded file from the request since Express middleware cannot by itself. Using multers limits, we only allow one file to be submitted with a max size of 1MB. 

The library nodemailer is used to send the email.

In the request service endpoint, we parse JSON from the body.formInputs. We sent the form data as JSON because we could not have nested objects otherwise (e.g profile.firstName) in the multi-part form. Information is extracted from the parsed formData using `structureToSend`. If labels not in `structureToSend` will be ignored. 

We compose the the formData into a simple HTML table. We escape the variables inserted into the HTML so that HTML cannot be injected into the email if a user submits HTML in the form.

The endpoints for survey and email submission currently just return a success. They should update a database (DigiClips' database?). The request service should also update the database after sending the email.

## Database

An outline of a database for the project might be structured:

Email Table:
Email Address
Email ID (PK)

Request Service Table
Submission Time (PK)
Email ID (PK, FK)
Other Fields

Survey Table
Other Fields

The survey table doesn't need a primary key as it is anonymous as it is now.

## Handoff

For information on where the last project group left off, please look at the Project_Handoff.pdf

This will explain how many different sections of code work, and will be a good resource for getting started.




