// https://medium.com/swlh/node-js-express-angular-stack-d6e328cffe6b
const express = require("express");
const nodemailer = require("nodemailer");
//require("dotenv").config();
const emailConfig = require("./config.json");
const he = require("html-escaper");
const multer = require("multer");
const upload = multer({
  storage: multer.memoryStorage(),
  limits: {
    files: 1,
    fileSize: 1000000,
  }
})

// Create new instance of the express server
var app = express();
const cors = require('cors')
var corsOptions = {
  origin: "*",
  optionsSuccessStatus: 200 // some legacy browsers (IE11, various SmartTVs) choke on 204
};
app.use(cors(corsOptions));

app.use(express.json());
app.use(express.urlencoded({ extended: true }));

// Create link to Angular build directory
// The `ng build` command will save the result
// under the `dist` folder.
var distDir = __dirname + "/dist/";
app.use(express.static(distDir));

app.use((req, res, next) => {
  res.header('Access-Control-Allow-Origin', '*');
  next();
})

let inProductionMode = false;
process.argv.forEach((val) => {
  if (val == "--production") {
    inProductionMode = true;
  }
});

// Init the server
var server = app.listen(process.env.PORT || 8080, function () {
  var port = server.address().port;
  console.log("App now running on port", port);
});

const table_style = `style="border: 1px solid black; border-collapse: collapse"`;

// stuctureToSend defines what fields to send in the email.
// It is an object where the keys are the names
// and the keys are either null or another object.
// A key is null if it is field (e.g. profile.firstName).
// A key is an object if it group of fields (e.g. profile).
const requestServiceStructure = {
  profile: {
    organization: null,
    firstName: null,
    lastName: null,
    address: {
      street: null,
      city: null,
      state: null,
      country: null,
      zip: null
    },
    phone: null,
    email: null,
  },
  professionallyEditedSegment: {
    professionallyEditedCheckbox: {
      television: null,
      radio: null,
      usaStatesMarkets: null,
      international: null
    }
  },
  tvFormat: null,
  tvResolution: null,
  reports: {
    mediaReports: null,
    reportStart: null,
    reportEnd: null,
    reportsCheckbox: null,
    reportMarkets: null
  },
  addOns: {
    keywords: null,
    transcripts: null,
    comments: null,
  }
}

const surveyStructure = {
  questions: {
    competitors: null,
    competitorsOther: null,
    likeComments: null,
    dislikeComments: null,
    missedData: null,
    scrapedData: null,
    mediaList: null,
    monitoredMedia: null,
    subscriptionPreferences: null,
    subscriptionRenewal: null,
    perNeed: null,
    needAnalytics: null,
    improveComments: null,
    needMediaReport: null,
    needBroadcastReport: null,
    needOnlineReport: null,
    needProfessionallyEditedSegment: null,
    macFormat: null,
    pcFormat: null,
    hdResolution: null,
    standardResolution: null,
    needTranscripts: null,
    needContacts: null,
    needArchived: null,
  }
}

/*  "/submit/requestservice"
    *   POST: Send form to server
    *   Server processes form,
    *   sends notification email to DigiClips employee,
    *   and adds form data to database (TODO)
    
    */
const db = require('../email_request/dbconnect_survey.js');

db.getPool().getConnection((err, connection) => {
  if (err) {
    console.error("Database connection failed:", err);
  } else {
    console.log("Database connected!");
    connection.release();
  }
});

// Make the database pool accessible to your application
app.use((req, res, next) => {
  req.db = db.getPool();
  next();
});

app.post("/submit/requestservice", upload.any(), function (req, res) {
  let body = {};

  if (req.body && req.body.formInputs) {
    body = JSON.parse(req.body.formInputs);
  }

  let emailType = "requestService";
  sendEmailWithAttachment(body, req, emailType);

  res.status(201);
  res.end("Success");
  //create a var to access the add_emailrequest file to make a function call
  //from the email_request file 
  const emailRequestData = extractEmailRequestDataFromBody(body);

  saveEmailRequestDataToDatabase(emailRequestData, (err, result) => {
    if (err) {
      console.error("Error saving email_request data:", err);

    } else {
      console.log("Email request data saved successfully");

    }
  });
});

// Function to extract email_request data from the form body
function extractEmailRequestDataFromBody(body) {
  const emailRequestData = {
    organization: body.profile.organization,
    firstName: body.profile.firstName,
    lastName: body.profile.lastName,

    street: body.profile.address.street,
    city: body.profile.address.city,
    state: body.profile.address.state,
    country: body.profile.address.country,
    zip: body.profile.address.zip,

    phone: body.profile.phone,
    email: body.profile.email,


    television: body.professionallyEditedSegment.professionallyEditedCheckbox.television,
    radio: body.professionallyEditedSegment.professionallyEditedCheckbox.radio,
    usaStatesMarkets: body.professionallyEditedSegment.professionallyEditedCheckbox.usaStatesMarkets,
    international: body.professionallyEditedSegment.professionallyEditedCheckbox.international,

    tvFormat: body.tvFormat,
    tvResolution: body.tvResolution,

    mediaReports: body.reports.mediaReports,
    reportStart: body.reports.reportStart,
    reportEnd: body.reports.reportEnd,
    reportsCheckbox: body.reports.reportsCheckbox,
    reportMarkets: body.reports.reportMarkets,


    keywords: body.addOns.keywords,
    transcripts: body.addOns.transcripts,
    comments: body.addOns.comments,

  };
  return emailRequestData;
}

// Function to save email_request data to the database
function saveEmailRequestDataToDatabase(emailRequestData, callback) {
  const query = "INSERT INTO Email_Request SET ?";

  db.getPool().getConnection((error, connection) => {
    if (error) {
      console.error("Error getting database connection:", error);
      callback(error, null);
    } else {
      connection.query(query, emailRequestData, (err, result) => {
        connection.release(); // Release the connection back to the pool
        if (err) {
          console.error("Error saving email_request data:", err);
          callback(err, null);
        } else {
          console.log("Email request data saved successfully");
          callback(null, result);
        }
      });
    }
  });
}

/**
  * "/submit/survey"
  * POST: sends survey to server
  * Processes the form
  * Sends notif to DigiClips employee specified in config.json
  * TODO: Adds the survey to the database
  */



app.post("/submit/survey", upload.any(), function (req, res) {
  let body = {};

  if (req.body && req.body.formInputs) {
    body = JSON.parse(req.body.formInputs);
  }

  let emailType = "survey";
  sendEmailWithAttachment(body, req, emailType);

  // Extract data from the survey and save it to the database
  const surveyData = extractSurveyDataFromBody(body);

  saveSurveyDataToDatabase(surveyData, (err, result) => {
    if (err) {
      console.error("Error saving survey data:", err);
      res.status(500).send("Error saving survey data");
    } else {
      console.log("Survey data saved successfully");
      res.status(201).send("Success");
    }
  });
});

function extractSurveyDataFromBody(body) {
  const surveyData = {
    competitors: body.questions.competitors,
    competitorsOther: body.questions.competitorsOther,
    likeComments: body.questions.likeComments,
    dislikeComments: body.questions.dislikeComments,
    missedData: body.questions.missedData,
    scrapedData: body.questions.scrapedData,
    mediaList: body.questions.mediaList,
    monitoredMedia: body.questions.monitoredMedia,
    subscriptionRenewal: body.questions.subscriptionRenewal,
    perNeed: body.questions.perNeed,
    needAnalytics: body.questions.needAnalytics,
    improveComments: body.questions.improveComments,
    needMediaReport: body.questions.needMediaReport,
    needBroadcastReport: body.questions.needBroadcastReport,
    needOnlineReport: body.questions.needOnlineReport,
    needProfessionallyEditedSegment: body.questions.needProfessionallyEditedSegment,
    macFormat: body.questions.macFormat,
    pcFormat: body.questions.pcFormat,
    hdResolution: body.questions.hdResolution,
    standardResolution: body.questions.standardResolution,
    needTranscripts: body.questions.needTranscripts,
    needContacts: body.questions.needContacts,
    needArchived: body.questions.needArchived,
  };

  return surveyData;
}

function saveSurveyDataToDatabase(surveyData, callback) {
  const query = "INSERT INTO survey_data SET ?"; // Assuming the table name is survey_data

  db.getConnection((error, connection) => {
    if (error) {
      console.error("Error getting database connection:", error);
      callback(error, null);
    } else {
      connection.query(query, surveyData, (err, result) => {
        connection.release(); // Release the connection back to the pool
        if (err) {
          console.error("Error saving survey data:", err);
          callback(err, null);
        } else {
          console.log("Survey data saved successfully");
          callback(null, result);
        }
      });
    }
  });

}



function extractSurveyDataFromBody(body) {
  const surveyData = {
    competitors: body.questions.competitors,
    competitorsOther: body.questions.competitorsOther,
    likeComments: body.questions.likeComments,
    dislikeComments: body.questions.dislikeComments,
    missedData: body.questions.missedData,
    scrapedData: body.questions.scrapedData,
    mediaList: body.questions.mediaList,
    monitoredMedia: body.questions.monitoredMedia,
    subscriptionRenewal: body.questions.subscriptionRenewal,
    perNeed: body.questions.perNeed,
    needAnalytics: body.questions.needAnalytics,
    improveComments: body.questions.improveComments,
    needMediaReport: body.questions.needMediaReport,
    needBroadcastReport: body.questions.needBroadcastReport,
    needOnlineReport: body.questions.needOnlineReport,
    needProfessionallyEditedSegment: body.questions.needProfessionallyEditedSegment,
    macFormat: body.questions.macFormat,
    pcFormat: body.questions.pcFormat,
    hdResolution: body.questions.hdResolution,
    standardResolution: body.questions.standardResolution,
    needTranscripts: body.questions.needTranscripts,
    needContacts: body.questions.needContacts,
    needArchived: body.questions.needArchived,
  };

  return surveyData;
}

function saveSurveyDataToDatabase(surveyData, callback) {

  const query = "INSERT INTO Survey_Data SET ?";

  db.query(query, surveyData, (err, result) => {
    if (err) {
      callback(err, null);
    } else {
      callback(null, result);
    }
  });
}


app.post("/submit/email", upload.any(), function (req, res) {
  //process survey here
  let body = {};

  if (req.body && req.body.formInputs) {
    body = JSON.parse(req.body.formInputs);
  }

  res.status(201);
  res.end("Success");
});

//==================Helper functions==================

function composeEmail(body, structure) {
  let html = `<table ${table_style}>`;

  html += addValues(body, structure);


  html += "</table>";
  return html;
}

function addValues(obj, structure) {
  let html = '';

  for (let key of Object.keys(structure)) {
    if (typeof obj !== "object" || !(key in obj)) {
      continue;
    }

    if (structure[key] === null) {
      html += addEntry(key, obj[key]);
    } else {
      html += `<tr ${table_style}><th ${table_style} colspan="2">${he.escape(key)}</th></tr>`;
      html += addValues(obj[key], structure[key]);
    }
  }

  return html;
}

function addEntry(key, val) {
  if (val == null) {
    val = "";
  }

  let html = `<tr ${table_style}><td ${table_style}>${he.escape(key)}</td><td ${table_style}>${he.escape(val)}</td></tr>`
  return html;
}


/**
    * It's in the function name
    * @param body: Body of your email
    * @param req: the original POST request of the calling POST handler
    * @param emailType: "requestService" or "survey", determines html structure and email subject/text
    */
function sendEmailWithAttachment(body, req, emailType) {
  //set the structure of the email to be sent out and compost it accordingly
  let structureToSend = null;
  let org = null;
  if (emailType == "requestService") {
    structureToSend = requestServiceStructure;
    org = body.profile.organization;
  }
  else if (emailType == "survey")
    structureToSend = surveyStructure;

  let email_html = composeEmail(body, structureToSend);

  //if there is an attachment, add it to the email
  let attachments = [];
  if (req.files && req.files[0] != undefined) {
    attachments = [
      {
        filename: req.files[0].originalname,
        content: req.files[0].buffer,
      }
    ]
  }
    ]
}


const transporter = nodemailer.createTransport(emailConfig.email);
const mailOptions = getMailOptions(emailType, email_html, attachments, org);

transporter.sendMail(mailOptions, function (err, info) {
  if (err) {
    console.log(err);
  } else {


  }
});
}

/**
    * Creates mailOptions from the inputs
    * @param emailType: "requestService" or "survey", determines subject and text
    * @param email_html: the email body in html
    * @param attachments: any attachments for your email
    */
function getMailOptions(emailType, email_html, attachments, org) {
  let textLine = org + " Request Service";
  if (emailType == "requestService") {
    const mailOptions = {
      from: emailConfig.email.from,
      // emailAddresses should be a string of comma-separated emails
      to: emailConfig.email.to,
      subject: textLine,
      text: 'New Service Request Received',
      text: 'New Service Request Received',
      html: email_html,
      attachments: attachments
    }
    attachments: attachments
  }
  return mailOptions;
}
  else if (emailType == "survey") {
}
else if (emailType == "survey") {
  const mailOptions = {
    from: emailConfig.email.from,
    to: emailConfig.email.to,
    subject: "Survey Submission Received",
    text: "New Survey Submitted",
    html: email_html,
    attachments: attachments
  }
  attachments: attachments
}
return mailOptions;
  }
}

