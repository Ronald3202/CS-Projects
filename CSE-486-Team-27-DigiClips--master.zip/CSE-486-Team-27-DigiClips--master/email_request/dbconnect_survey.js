
const mysql = require('mysql');

const connectionInfo = require('./decrypt_credentials_survey.js');

const connectionLimit = 20;
let pool;

function createPool() {
  pool = mysql.createPool({
    connectionLimit: connectionLimit,
    host: connectionInfo.host,
    user: connectionInfo.user,
    password: connectionInfo.password,
    database: 'dc'
  });
}

createPool();

module.exports = {
  getPool: function () {
    return pool;
  },
  query: function (sql, values, callback) {
    pool.getConnection(function (err, connection) {
      if (err) {
        return callback(err);
      }
      connection.query(sql, values, function (err, results) {
        connection.release();
        callback(err, results);
      });
    });
  }
};

