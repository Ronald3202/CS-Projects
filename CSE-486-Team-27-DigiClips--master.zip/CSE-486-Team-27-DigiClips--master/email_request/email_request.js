'use strict';
var db = require('./dbconnect.js');
var moment = require('moment');

module.exports.addEmailRequest = function(username, userEmail, subject, message, phone, organization, address_street, address_city, address_state, address_country, address_zip, order_number, order_type, affiliat, markets, tv_station, tv_file_format, tv_display_format, tv_res, radio_station, radio_file_format, news_and_mags, keywords, comments callback) {
  var pool = db.getPool();    
  pool.getConnection(function(err, connection) {
    if (err) {
      console.log('Error getting connection from pool:', err);
      return callback(err);
    }
    
    var timestamp = moment().format('YYYY-MM-DD HH:mm:ss');
    var query = "INSERT INTO dc.email_requests (user_name, user_email, subject, message, created_at, phone, organization, address_street, address_city, address_state, address_country, address_zip, order_number, order_type, affiliat, markets, tv_station, tv_file_format, tv_display_format, tv_res, radio_station, radio_file_format, news_and_mags, keywords, comments) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)";
    var values = [username, userEmail, subject, message, timestamp, phone, organization, address_street, address_city, address_state, address_country, address_zip, order_number, order_type, affiliat, markets, tv_station, tv_file_format, tv_display_format, tv_res, radio_station, radio_file_format, news_and_mags, keywords, comments];

    
    connection.query(query, values, function(err, result) {
      connection.release();
      
      if (err) {
        console.log('Error executing query:', err);
        return callback(err);
      }
      
      console.log('Query result:', result);
      callback(null, result);
    });
  });
};
