// dbsurvey.js
const mysql = require("mysql");
const dbConfig = require("../email_request/dbconfig.js"); // Assuming you have a dbConfig.js file

const pool = mysql.createPool(dbConfig);

function checkDatabaseConnection() {
  pool.getConnection((err, connection) => {
    if (err) {
      console.error("Error connecting to the database:", err);
      return;
    }
    console.log("Database connection successful");
    connection.release();
  });
}

module.exports = {
  pool,
  checkDatabaseConnection,
};

