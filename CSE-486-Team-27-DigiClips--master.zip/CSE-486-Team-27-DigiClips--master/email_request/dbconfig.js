// dbConfig.js
module.exports = {
  host: "192.168.50.2",
  port: "3306",
  user: "henry",
  password: "DropInn#12",
  database: "DC" // Specify the database name
};
