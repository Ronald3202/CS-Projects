'use strict';
//var emailRequest = require('./email_request/email_request.js');
var emailRequest = require('./email_request.js');
module.exports.userRequest = userRequest;

//emailRequest.addEmailRequest(user_name, user_email, subject, message, created_at, phone, organization, address_street, address_city, address_state, address_country, address_zip, order_number, order_type, affiliat, markets, tv_station, tv_file_format, tv_display_format, tv_res, radio_station, radio_file_format, news_and_mags, keywords, commments, function(err, result) 

module.exports.emailRequest.addEmailRequest(userRequest, function(err, result){
//emailRequest.addEmailRequest(userRequest, function(err, result)){
       if(err) {
           console.log(err);
       } else {
           console.log(result);
    }
});  

