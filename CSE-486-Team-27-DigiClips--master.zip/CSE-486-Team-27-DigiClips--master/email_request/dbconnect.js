//const { getConnectionInfo } = require('./decrypt_credentials.js');
const getConnectionInfo = require('./decrypt_credentials.js');

const mysql = require('mysql');

const connectionInfo = getConnectionInfo();

const connectionLimit = 20;
let pool;

function createPool() {
  pool = mysql.createPool({
    connectionLimit: connectionLimit,
    host: connectionInfo.host,
    user: connectionInfo.user,
    password: connectionInfo.password,
    database: connectionInfo.database
  });
}

createPool();

module.exports = {
  getPool: function() {
    return pool;
  }
};
